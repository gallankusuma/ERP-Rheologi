import cron from 'node-cron';
import { dbAll, dbRun, dbGet } from './config/database';

export const initCronJobs = () => {
  // Run every day at 01:00 AM
  cron.schedule('0 1 * * *', async () => {
    console.log('[CRON] Running daily document expiry check...');
    try {
      const docs = await dbAll(`SELECT * FROM document_control WHERE expiry_date IS NOT NULL AND status NOT IN ('Renewed')`);
      const admins = await dbAll(`SELECT u.id FROM users u JOIN roles r ON u.role_id = r.id WHERE r.name = 'Admin'`) as any[];
      let notificationsCreated = 0;
      const now = new Date();

      for (const doc of docs as any[]) {
        const expiryDate = new Date(doc.expiry_date);
        const reminderDays = doc.reminder_days || 30;
        const diffTime = expiryDate.getTime() - now.getTime();
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays <= reminderDays) {
          let newStatus = doc.status;
          if (diffDays < 0) {
            newStatus = 'Expired';
          } else if (newStatus === 'Active') {
            newStatus = 'Expiring Soon';
          }
          if (newStatus !== doc.status) {
             await dbRun('UPDATE document_control SET status = ? WHERE id = ?', [newStatus, doc.id]);
          }

          for (const admin of admins) {
            const recentNotif = await dbGet(
              `SELECT id FROM notifications WHERE recipient_id = ? AND related_entity_type = 'Document' AND related_entity_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)`,
              [admin.id, doc.id]
            );
            if (!recentNotif) {
               const title = diffDays < 0 ? 'Document Expired' : 'Document Expiring Soon';
               const message = `The document ${doc.document_name} (${doc.document_number}) ${diffDays < 0 ? 'has expired' : 'is expiring in ' + diffDays + ' days'}.`;
               await dbRun(
                 `INSERT INTO notifications (recipient_id, title, message, type, related_entity_type, related_entity_id, action_url, is_read) VALUES (?, ?, ?, ?, ?, ?, ?, 0)`,
                 [admin.id, title, message, 'alert', 'Document', doc.id, '/admin/document-control']
               );
               notificationsCreated++;
            }
          }
        }
      }
      console.log(`[CRON] Expiry check completed. Created ${notificationsCreated} notifications.`);
    } catch (error) {
      console.error('[CRON] Error checking expiries:', error);
    }
  });
};
