import { Router, Request, Response } from 'express';
import { dbAll, dbRun, dbGet } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = Router();

// GET /api/sample-requests
router.get('/', authMiddleware, async (req: Request, res: Response) => {
    try {
        const requests = await dbAll(
            `SELECT sr.*, 
                    c.name as client_name,
                    u.full_name as sales_user_name,
                    r.full_name as rnd_user_name
             FROM sample_requests sr
             LEFT JOIN clients c ON sr.client_id = c.id
             LEFT JOIN users u ON sr.sales_user_id = u.id
             LEFT JOIN users r ON sr.rnd_user_id = r.id
             ORDER BY sr.created_at DESC`,
             []
        );
        res.json({ data: requests });
    } catch (error) {
        console.error('Error fetching sample requests:', error);
        res.status(500).json({ error: 'Failed to fetch sample requests' });
    }
});

// POST /api/sample-requests
router.post('/', authMiddleware, async (req: Request, res: Response) => {
    try {
        const { client_id, sales_user_id, product_name, specifications, quantity, unit, target_delivery_date } = req.body;
        
        if (!client_id || !sales_user_id || !product_name) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        // Generate Request Number (SR-YYYYMM-001)
        const date = new Date();
        const yearMonth = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, '0')}`;
        const lastReq = await dbGet('SELECT request_number FROM sample_requests WHERE request_number LIKE ? ORDER BY id DESC LIMIT 1', [`SR-${yearMonth}-%`]) as any;
        
        let seq = 1;
        if (lastReq) {
            const parts = lastReq.request_number.split('-');
            seq = parseInt(parts[2], 10) + 1;
        }
        const request_number = `SR-${yearMonth}-${String(seq).padStart(3, '0')}`;

        const result = await dbRun(
            `INSERT INTO sample_requests 
            (request_number, client_id, sales_user_id, product_name, specifications, quantity, unit, target_delivery_date, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Requested')`,
            [request_number, client_id, sales_user_id, product_name, specifications, quantity || 1, unit || 'pcs', target_delivery_date || null]
        );

        res.json({ success: true, message: 'Sample request created', id: result.insertId });
    } catch (error) {
        console.error('Error creating sample request:', error);
        res.status(500).json({ error: 'Failed to create sample request' });
    }
});

// PUT /api/sample-requests/:id/status
router.put('/:id/status', authMiddleware, async (req: Request, res: Response) => {
    try {
        const { status, delivery_tracking, rnd_user_id } = req.body;
        
        if (!status) {
            return res.status(400).json({ error: 'Status is required' });
        }

        const currentReq = await dbGet('SELECT * FROM sample_requests WHERE id = ?', [req.params.id]) as any;
        if (!currentReq) {
             return res.status(404).json({ error: 'Request not found' });
        }

        const newTracking = delivery_tracking !== undefined ? delivery_tracking : currentReq.delivery_tracking;
        const newRndUser = rnd_user_id !== undefined ? rnd_user_id : currentReq.rnd_user_id;

        await dbRun(
            `UPDATE sample_requests SET status = ?, delivery_tracking = ?, rnd_user_id = ? WHERE id = ?`,
            [status, newTracking, newRndUser, req.params.id]
        );

        res.json({ success: true, message: 'Status updated successfully' });
    } catch (error) {
        console.error('Error updating status:', error);
        res.status(500).json({ error: 'Failed to update status' });
    }
});

// PUT /api/sample-requests/:id/feedback
router.put('/:id/feedback', authMiddleware, async (req: Request, res: Response) => {
    try {
        const { client_feedback } = req.body;
        
        if (!client_feedback) {
            return res.status(400).json({ error: 'Feedback is required' });
        }

        await dbRun(
            `UPDATE sample_requests SET client_feedback = ?, feedback_date = CURRENT_TIMESTAMP, status = 'Feedback Received' WHERE id = ?`,
            [client_feedback, req.params.id]
        );

        res.json({ success: true, message: 'Feedback added successfully' });
    } catch (error) {
        console.error('Error adding feedback:', error);
        res.status(500).json({ error: 'Failed to add feedback' });
    }
});

export default router;
