import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = Router();

// Helper: PPIC audit log
const ppicLog = async (req: Request, action: string, entityType: string, entityId: any, oldValues?: any, newValues?: any) => {
  try {
    const userId = (req as any).user?.userId || null;
    const ip = req.ip || req.headers['x-forwarded-for'] || '';
    await dbRun(
      `INSERT INTO audit_log (user_id, action, entity_type, entity_id, old_values, new_values, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, action, entityType, entityId || null, oldValues ? JSON.stringify(oldValues) : null, newValues ? JSON.stringify(newValues) : null, ip]
    );
  } catch (e) {
    console.error('PPIC audit log error:', e);
  }
};

// ==========================================
// ITEM MASTER (FG, RM, PM)
// ==========================================
router.get('/items', authMiddleware, async (req: Request, res: Response) => {
    try {
        const { type } = req.query;
        let query = `
            SELECT p.*, c.name as category_name, pt.name as type_name, u.name as uom_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
            LEFT JOIN product_types pt ON p.product_type_id = pt.id
            LEFT JOIN uom u ON p.unit_of_measure_id = u.id
            WHERE p.active = 1
        `;
        const params: any[] = [];
        if (type) { query += ` AND pt.code = ?`; params.push(type); }
        query += ` ORDER BY p.name ASC`;
        const items = await dbAll(query, params);
        res.json({ data: items });
    } catch (error) {
        console.error('Error fetching PPIC items:', error);
        res.status(500).json({ error: 'Failed to fetch items' });
    }
});

// ==========================================
// BILL OF MATERIALS (BOM)
// ==========================================
router.get('/boms', authMiddleware, async (req: Request, res: Response) => {
    try {
        const boms = await dbAll(`
            SELECT b.*, p.name as product_name, p.sku as product_sku
            FROM bom_headers b LEFT JOIN products p ON b.product_id = p.id
            ORDER BY b.created_at DESC
        `);
        res.json({ data: boms });
    } catch (error) { res.status(500).json({ error: 'Failed to fetch BOMs' }); }
});

router.get('/boms/:id', authMiddleware, async (req: Request, res: Response) => {
    try {
        const bomId = req.params.id;
        const header = await dbGet(`
            SELECT b.*, p.name as product_name, p.sku as product_sku, u.name as uom_name
            FROM bom_headers b
            LEFT JOIN products p ON b.product_id = p.id
            LEFT JOIN uom u ON p.unit_of_measure_id = u.id
            WHERE b.id = ?
        `, [bomId]);
        if (!header) return res.status(404).json({ error: 'BOM not found' });
        const details = await dbAll(`
            SELECT bd.*, p.name as material_name, p.sku as material_sku, u.name as uom_name
            FROM bom_details bd
            LEFT JOIN products p ON bd.raw_material_id = p.id
            LEFT JOIN uom u ON bd.unit_of_measure_id = u.id
            WHERE bd.bom_header_id = ? ORDER BY bd.sequence ASC
        `, [bomId]);
        res.json({ data: { header, details } });
    } catch (error) { res.status(500).json({ error: 'Failed to fetch BOM details' }); }
});

// ==========================================
// MPS — MASTER PRODUCTION SCHEDULE
// ==========================================

// Helper: get ISO week number
function getWeekNumber(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

// Helper: get date range for ISO week
function getWeekDateRange(year: number, week: number): { start: string; end: string } {
  const jan4 = new Date(year, 0, 4);
  const dayOfWeek = jan4.getDay() || 7;
  const monday = new Date(jan4);
  monday.setDate(jan4.getDate() - dayOfWeek + 1 + (week - 1) * 7);
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  const fmt = (d: Date) => `${d.getDate()}/${d.getMonth() + 1}`;
  return { start: fmt(monday), end: fmt(sunday) };
}

// GET /mps - List MPS headers
router.get('/mps', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { year, month, status } = req.query;
    let query = `
      SELECT m.*, u.full_name as created_by_name, cu.full_name as confirmed_by_name,
        (SELECT COUNT(*) FROM mps_details WHERE mps_header_id = m.id) as item_count
      FROM mps_headers m
      LEFT JOIN users u ON m.created_by = u.id
      LEFT JOIN users cu ON m.confirmed_by = cu.id
      WHERE 1=1
    `;
    const params: any[] = [];
    if (year) { query += ' AND m.period_year = ?'; params.push(year); }
    if (month) { query += ' AND m.period_month = ?'; params.push(month); }
    if (status) { query += ' AND m.status = ?'; params.push(status); }
    query += ' ORDER BY m.period_year DESC, m.period_month DESC';
    const rows = await dbAll(query, params);
    res.json({ data: rows });
  } catch (error) {
    console.error('Error fetching MPS list:', error);
    res.status(500).json({ error: 'Failed to fetch MPS list' });
  }
});

// GET /mps/:id - Get MPS with details + weekly grid
router.get('/mps/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const header = await dbGet(`
      SELECT m.*, u.full_name as created_by_name, cu.full_name as confirmed_by_name
      FROM mps_headers m
      LEFT JOIN users u ON m.created_by = u.id
      LEFT JOIN users cu ON m.confirmed_by = cu.id
      WHERE m.id = ?
    `, [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });

    const details = await dbAll(`
      SELECT d.*,
        p.name as product_name, p.sku as product_sku,
        um.name as uom_name,
        bh.product_name as bom_name, bh.version as bom_version,
        cp.project_number, cp.project_name, cp.status as project_status,
        c.name as client_name,
        wo.wo_number, wo.status as wo_status, wo.completed_quantity as wo_completed_qty,
        so.so_number, so.status as so_status
      FROM mps_details d
      LEFT JOIN products p ON d.product_id = p.id
      LEFT JOIN uom um ON p.unit_of_measure_id = um.id
      LEFT JOIN bom_headers bh ON d.bom_id = bh.id
      LEFT JOIN client_projects cp ON d.project_id = cp.id
      LEFT JOIN clients c ON cp.client_id = c.id
      LEFT JOIN work_orders wo ON d.wo_id = wo.id
      LEFT JOIN sales_orders so ON cp.so_id = so.id
      WHERE d.mps_header_id = ?
      ORDER BY d.id ASC
    `, [id]);

    // Load weekly grid data for all details
    const detailIds = (details as any[]).map((d: any) => d.id);
    let weekData: any[] = [];
    if (detailIds.length > 0) {
      const placeholders = detailIds.map(() => '?').join(',');
      weekData = await dbAll(`
        SELECT * FROM mps_week_data
        WHERE mps_detail_id IN (${placeholders})
        ORDER BY year, week_number
      `, detailIds) as any[];
    }

    // For each detail, enrich with: FG stock, capacity, material status
    const enrichedDetails = [];
    for (const d of (details as any[])) {
      const detail = { ...d, weeks: weekData.filter((w: any) => w.mps_detail_id === d.id) };

      // 1. FG Stock from inventory
      const fgStockRow = await dbGet(
        'SELECT COALESCE(SUM(quantity), 0) as total_stock FROM inventory_stocks WHERE product_id = ?',
        [d.product_id]
      ) as any;
      detail.fg_inventory_stock = Number(fgStockRow?.total_stock || 0);

      // 2. WO actual output (completed qty from all related WOs)
      const woOutput = await dbGet(
        "SELECT COALESCE(SUM(completed_quantity), 0) as total_completed FROM work_orders WHERE product_id = ? AND status IN ('COMPLETED', 'IN_PROGRESS')",
        [d.product_id]
      ) as any;
      detail.wo_actual_output = Number(woOutput?.total_completed || 0);

      // 3. Line capacity
      const lineInfo = await dbGet(`
        SELECT lp.id, lp.name as line_name, lp.capacity_per_hour, lp.capacity_unit,
          lp.working_hours_per_week
        FROM line_process_products lpp
        JOIN line_processes lp ON lpp.line_process_id = lp.id AND lp.active = 1
        WHERE lpp.product_id = ?
        LIMIT 1
      `, [d.product_id]) as any;
      detail.line_process_id = lineInfo?.id || null;
      detail.line_name = lineInfo?.line_name || null;
      detail.capacity_per_hour = Number(lineInfo?.capacity_per_hour || 0);
      detail.working_hours_per_week = Number(lineInfo?.working_hours_per_week || 40);
      // max_weekly_capacity = capacity_per_hour × working_hours_per_week (from master)
      detail.max_weekly_capacity = detail.capacity_per_hour > 0
        ? Math.round(detail.capacity_per_hour * detail.working_hours_per_week * 100) / 100
        : 0;

      // 4. BOM material availability
      if (d.bom_id) {
        const bomDetails = await dbAll(`
          SELECT bd.raw_material_id, bd.quantity as quantity_per_unit, bd.unit_of_measure_id,
            p.name as material_name, p.sku as material_sku,
            COALESCE((SELECT SUM(quantity) FROM inventory_stocks WHERE product_id = bd.raw_material_id), 0) as stock_qty
          FROM bom_details bd
          LEFT JOIN products p ON bd.raw_material_id = p.id
          WHERE bd.bom_header_id = ?
          ORDER BY bd.sequence ASC
        `, [d.bom_id]) as any[];
        detail.bom_materials = bomDetails.map((m: any) => ({
          material_id: m.raw_material_id,
          material_name: m.material_name,
          material_sku: m.material_sku,
          qty_per_unit: Number(m.quantity_per_unit || 0),
          stock_qty: Number(m.stock_qty || 0),
          // Max producible from this material alone
          max_producible: m.quantity_per_unit > 0 ? Math.floor(Number(m.stock_qty) / Number(m.quantity_per_unit)) : 999999
        }));
        // Material bottleneck = min of all max_producible
        detail.material_max_producible = detail.bom_materials.length > 0
          ? Math.min(...detail.bom_materials.map((m: any) => m.max_producible))
          : 0;
      } else {
        detail.bom_materials = [];
        detail.material_max_producible = 0;
      }

      enrichedDetails.push(detail);
    }

    // Generate week columns info — start from first ISO week of MPS period_month/period_year
    const numWeeks = 12;
    const mpsMonth = Number(header.period_month) || (new Date().getMonth() + 1);
    const mpsYear  = Number(header.period_year)  || new Date().getFullYear();
    // Find the ISO week of the 1st day of the MPS period month
    const firstOfMonth = new Date(mpsYear, mpsMonth - 1, 1);
    const startWeek = getWeekNumber(firstOfMonth);
    const startYear = firstOfMonth.getFullYear();
    const weekColumns = [];
    for (let i = 0; i < numWeeks; i++) {
      let wk = startWeek + i;
      let yr = startYear;
      if (wk > 52) { wk -= 52; yr++; }
      const range = getWeekDateRange(yr, wk);
      weekColumns.push({ week: wk, year: yr, label: `W${wk}`, dateRange: `${range.start}-${range.end}` });
    }

    res.json({ data: { header, details: enrichedDetails, weekColumns } });
  } catch (error) {
    console.error('Error fetching MPS detail:', error);
    res.status(500).json({ error: 'Failed to fetch MPS detail' });
  }
});

// POST /mps - Create new MPS header
router.post('/mps', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { period_year, period_month, scheme, notes } = req.body;
    const userId = (req as any).user?.id || null;
    const existing = await dbGet(
      'SELECT id FROM mps_headers WHERE period_year = ? AND period_month = ? AND scheme = ?',
      [period_year, period_month, scheme || 'MTO']
    );
    if (existing) return res.status(400).json({ error: `MPS for ${period_year}-${String(period_month).padStart(2, '0')} already exists` });

    const mpsNumber = `MPS-${period_year}-${String(period_month).padStart(2, '0')}`;
    const result = await dbRun(
      `INSERT INTO mps_headers (mps_number, period_year, period_month, scheme, notes, created_by) VALUES (?, ?, ?, ?, ?, ?)`,
      [mpsNumber, period_year, period_month, scheme || 'MTO', notes || null, userId]
    );
    await ppicLog(req, 'CREATE', 'MPS', result.insertId, null, { mps_number: mpsNumber, period_year, period_month });
    res.status(201).json({ message: 'MPS created', data: { id: result.insertId, mps_number: mpsNumber } });
  } catch (error) {
    console.error('Error creating MPS:', error);
    res.status(500).json({ error: 'Failed to create MPS' });
  }
});

// POST /mps/:id/pull-orders - Pull demand from SO Items + Projects into MPS
router.post('/mps/:id/pull-orders', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Can only pull orders into Draft MPS' });

    const startDate = `${header.period_year}-${String(header.period_month).padStart(2, '0')}-01`;
    const endDate = `${header.period_year}-${String(header.period_month).padStart(2, '0')}-31`;

    // Source 1: Sales Order Items
    let soItems: any[] = [];
    try {
      soItems = await dbAll(`
        SELECT 'SO' as source_type, si.id as source_id, si.product_id, si.quantity,
          so.id as so_id, so.so_date as ref_date, CONCAT('SO-', so.so_number) as ref_label,
          p.name as product_name, p.sku as product_sku,
          bh.id as bom_id
        FROM so_items si
        JOIN sales_orders so ON si.so_id = so.id
        JOIN products p ON si.product_id = p.id
        LEFT JOIN bom_headers bh ON bh.product_id = si.product_id AND bh.status = 'ACTIVE'
        WHERE so.status IN ('OPEN', 'open', 'APPROVED', 'CONFIRMED', 'PROCESSING', 'DRAFT', 'confirmed')
          AND (so.so_date BETWEEN ? AND ? OR so.so_date <= ?)
          AND si.id NOT IN (
            SELECT COALESCE(so_item_id, 0) FROM mps_details WHERE so_item_id IS NOT NULL
          )
      `, [startDate, endDate, endDate]) as any[];
    } catch { soItems = []; }

    // Source 2: Client Projects (where product_id is linked)
    let projItems: any[] = [];
    try {
      projItems = await dbAll(`
        SELECT 'PROJECT' as source_type, cp.id as source_id, cp.product_id, cp.quantity,
          cp.so_id as linked_so_id,
          COALESCE(cp.start_date, cp.created_at) as ref_date,
          CONCAT('PRJ-', cp.project_number) as ref_label,
          p.name as product_name, p.sku as product_sku,
          bh.id as bom_id
        FROM client_projects cp
        JOIN products p ON cp.product_id = p.id
        LEFT JOIN bom_headers bh ON bh.product_id = cp.product_id AND bh.status = 'ACTIVE'
        WHERE cp.status IN ('open', 'in_progress')
          AND cp.product_id IS NOT NULL
          AND (
            cp.start_date BETWEEN ? AND ?
            OR cp.end_date BETWEEN ? AND ?
            OR (cp.start_date <= ? AND cp.end_date >= ?)
            OR cp.start_date IS NULL
          )
          AND cp.id NOT IN (
            SELECT COALESCE(project_id, 0) FROM mps_details WHERE project_id IS NOT NULL
          )
      `, [startDate, endDate, startDate, endDate, startDate, endDate]) as any[];
    } catch { projItems = []; }

    // Deduplicate: If a Project was created from an SO, remove SO items from that same SO
    // Projects take priority (they represent committed demand)
    const projSoIds = new Set<number>();
    for (const proj of projItems) {
      if (proj.linked_so_id) projSoIds.add(proj.linked_so_id);
    }
    const dedupedSoItems = projSoIds.size > 0
      ? soItems.filter((si: any) => !projSoIds.has(si.so_id))
      : soItems;

    const allItems = [...dedupedSoItems, ...projItems];

    // Filter out products that already exist in this MPS
    const existingProducts = await dbAll(
      'SELECT DISTINCT product_id FROM mps_details WHERE mps_header_id = ?', [id]
    ) as any[];
    const existingProductIds = new Set(existingProducts.map((p: any) => p.product_id));
    const newItems = allItems.filter((item: any) => !existingProductIds.has(item.product_id));

    if (newItems.length === 0) {
      return res.json({ message: 'No new orders found. All products already in MPS.', pulled: 0 });
    }

    const now = new Date();
    const currentWeek = getWeekNumber(now);
    const currentYear = now.getFullYear();

    // Group items by product_id — merge same products from different SOs
    const productMap = new Map<number, {
      product_id: number;
      bom_id: number | null;
      total_qty: number;
      so_numbers: string[];
      project_numbers: string[];
      // Per-week qty distribution: key = "week:year", value = qty
      weekQtyMap: Map<string, number>;
    }>();

    for (const item of newItems) {
      const pid = item.product_id;
      const qty = Number(item.quantity || 0);

      if (!productMap.has(pid)) {
        productMap.set(pid, {
          product_id: pid,
          bom_id: item.bom_id || null,
          total_qty: 0,
          so_numbers: [],
          project_numbers: [],
          weekQtyMap: new Map()
        });
      }
      const group = productMap.get(pid)!;
      group.total_qty += qty;

      // Collect SO/Project references
      if (item.source_type === 'SO' && item.ref_label) {
        group.so_numbers.push(item.ref_label);
      } else if (item.source_type === 'PROJECT' && item.ref_label) {
        group.project_numbers.push(item.ref_label);
      }

      // Distribute qty to the correct week based on ref_date
      const refDate = item.ref_date ? new Date(item.ref_date) : now;
      const refWeek = getWeekNumber(refDate);
      const refYear = refDate.getFullYear();
      const weekKey = `${refWeek}:${refYear}`;
      group.weekQtyMap.set(weekKey, (group.weekQtyMap.get(weekKey) || 0) + qty);
    }

    let pulled = 0;
    for (const [, group] of productMap) {
      const soNumsStr = group.so_numbers.join(', ') || null;

      // Insert 1 MPS detail per product
      const detailResult = await dbRun(`
        INSERT INTO mps_details (mps_header_id, product_id, bom_id, so_numbers,
          demand_qty, current_stock, batch_no, batch_qty, lead_time_weeks, status)
        VALUES (?, ?, ?, ?, ?, 0, NULL, 0, 1, 'Pending')
      `, [id, group.product_id, group.bom_id, soNumsStr, group.total_qty]);

      const detailId = detailResult.insertId;

      // Create 12 weeks of grid data with distributed SO qty
      // First, collect any qty from weeks BEFORE the grid start → put into first grid week
      const firstWeekKey = `${currentWeek}:${currentYear}`;
      for (const [wKey, wQty] of group.weekQtyMap) {
        const [wStr, yStr] = wKey.split(':');
        const w = Number(wStr), y = Number(yStr);
        // If this week is before the grid start, move qty to first week
        if (y < currentYear || (y === currentYear && w < currentWeek)) {
          group.weekQtyMap.set(firstWeekKey, (group.weekQtyMap.get(firstWeekKey) || 0) + wQty);
          group.weekQtyMap.delete(wKey);
        }
      }

      for (let i = 0; i < 12; i++) {
        let wk = currentWeek + i;
        let yr = currentYear;
        if (wk > 52) { wk -= 52; yr++; }

        const weekKey = `${wk}:${yr}`;
        const weekQty = group.weekQtyMap.get(weekKey) || 0;
        await dbRun(`
          INSERT INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty, production_qty)
          VALUES (?, ?, ?, 0, ?, 0, 0, 0)
        `, [detailId, wk, yr, weekQty]);
      }
      pulled++;
    }

    await ppicLog(req, 'PULL_ORDERS', 'MPS', id, null, { pulled, from_so: dedupedSoItems.length, from_projects: projItems.length });
    res.json({
      message: `${pulled} products pulled into MPS (from ${allItems.length} order lines)`,
      pulled,
      from_so: dedupedSoItems.length,
      from_projects: projItems.length
    });
  } catch (error) {
    console.error('Error pulling orders:', error);
    res.status(500).json({ error: 'Failed to pull orders' });
  }
});

// POST /mps/:id/add-item - Manually add an item to MPS (e.g. from forecast)
router.post('/mps/:id/add-item', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { product_id, bom_id: reqBomId, quantity, target_week, target_year, notes } = req.body;

    if (!product_id) return res.status(400).json({ error: 'product_id is required' });

    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Can only add items to Draft MPS' });

    // Get product info
    const product = await dbGet('SELECT id, name, sku FROM products WHERE id = ?', [product_id]) as any;
    if (!product) return res.status(404).json({ error: 'Product not found' });

    // Use provided bom_id or fallback to auto-lookup
    let bomId = reqBomId || null;
    if (!bomId) {
      const bom = await dbGet(
        "SELECT id FROM bom_headers WHERE product_id = ? AND status = 'ACTIVE' LIMIT 1",
        [product_id]
      ) as any;
      bomId = bom?.id || null;
    }

    const qty = Number(quantity || 0);

    // Insert MPS detail
    const detailResult = await dbRun(`
      INSERT INTO mps_details (mps_header_id, product_id, bom_id,
        demand_qty, current_stock, batch_no, batch_qty, lead_time_weeks, status)
      VALUES (?, ?, ?, ?, 0, NULL, 0, 1, 'Pending')
    `, [id, product_id, bomId, qty]);

    const detailId = detailResult.insertId;

    // Create 12 weeks of grid data
    const now = new Date();
    const currentWeek = getWeekNumber(now);
    const currentYear = now.getFullYear();
    const tgtWeek = target_week ? Number(target_week) : null;
    const tgtYear = target_year ? Number(target_year) : currentYear;

    for (let i = 0; i < 12; i++) {
      let wk = currentWeek + i;
      let yr = currentYear;
      if (wk > 52) { wk -= 52; yr++; }

      const isTargetWeek = tgtWeek ? (wk === tgtWeek && yr === tgtYear) : (i === 0);
      await dbRun(`
        INSERT INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty)
        VALUES (?, ?, ?, ?, 0, 0, 0)
      `, [detailId, wk, yr, isTargetWeek ? qty : 0]);
    }

    await ppicLog(req, 'ADD_ITEM', 'MPS_DETAIL', detailId, null, { mps_id: id, product_name: product.name, quantity: qty });
    res.status(201).json({
      message: `Product "${product.name}" added to MPS`,
      data: { id: detailId, product_name: product.name, quantity: qty }
    });
  } catch (error) {
    console.error('Error adding item to MPS:', error);
    res.status(500).json({ error: 'Failed to add item to MPS' });
  }
});

// PUT /mps/:id/details/:detailId/remark - Update remark info (stock, batch, lead time)
router.put('/mps/:id/details/:detailId/remark', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    const { current_stock, batch_no, batch_qty, lead_time_weeks, buffer_stock } = req.body;
    const cs = current_stock ?? null;
    const bn = batch_no ?? null;
    const bq = batch_qty ?? null;
    const lt = lead_time_weeks ?? null;
    const bs = buffer_stock ?? null;

    const header = await dbGet('SELECT status FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });

    await dbRun(`
      UPDATE mps_details SET
        current_stock = COALESCE(?, current_stock),
        batch_no = COALESCE(?, batch_no),
        batch_qty = COALESCE(?, batch_qty),
        lead_time_weeks = COALESCE(?, lead_time_weeks),
        buffer_stock = COALESCE(?, buffer_stock)
      WHERE id = ? AND mps_header_id = ?
    `, [cs, bn, bq, lt, bs, detailId, id]);

    res.json({ message: 'Remark updated' });
  } catch (error) {
    console.error('Error updating remark:', error);
    res.status(500).json({ error: 'Failed to update remark' });
  }
});

// PUT /mps/:id/week-data - Bulk update weekly grid cells
router.put('/mps/:id/week-data', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { entries } = req.body; // [{ mps_detail_id, week_number, year, field, value }]

    const header = await dbGet('SELECT status FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });

    for (const entry of (entries || [])) {
      const allowedFields = ['forecast_qty', 'so_qty', 'start_process_qty', 'fg_qty', 'production_qty'];
      if (!allowedFields.includes(entry.field)) continue;

      // Upsert
      const existing = await dbGet(
        'SELECT id FROM mps_week_data WHERE mps_detail_id = ? AND year = ? AND week_number = ?',
        [entry.mps_detail_id, entry.year, entry.week_number]
      );

      if (existing) {
        await dbRun(
          `UPDATE mps_week_data SET ${entry.field} = ? WHERE mps_detail_id = ? AND year = ? AND week_number = ?`,
          [entry.value || 0, entry.mps_detail_id, entry.year, entry.week_number]
        );
      } else {
        const insertObj: any = { forecast_qty: 0, so_qty: 0, start_process_qty: 0, fg_qty: 0, production_qty: 0 };
        insertObj[entry.field] = entry.value || 0;
        await dbRun(`
          INSERT INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty, production_qty)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [entry.mps_detail_id, entry.week_number, entry.year, insertObj.forecast_qty, insertObj.so_qty, insertObj.start_process_qty, insertObj.fg_qty, insertObj.production_qty]);
      }
    }

      await ppicLog(req, 'SAVE_WEEK_DATA', 'MPS', id, null, { entries_count: entries.length });
      res.json({ message: 'Week data updated' });
  } catch (error) {
    console.error('Error updating week data:', error);
    res.status(500).json({ error: 'Failed to update week data' });
  }
});

// POST /mps/:id/confirm
router.post('/mps/:id/confirm', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.id || null;
    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Only Draft MPS can be confirmed' });

    const detailCount = await dbGet('SELECT COUNT(*) as cnt FROM mps_details WHERE mps_header_id = ?', [id]) as any;
    if (!detailCount || detailCount.cnt === 0) return res.status(400).json({ error: 'Cannot confirm empty MPS' });

    await dbRun('UPDATE mps_headers SET status = ?, confirmed_by = ?, confirmed_at = NOW() WHERE id = ?', ['Confirmed', userId, id]);
    await dbRun('UPDATE mps_details SET status = ? WHERE mps_header_id = ? AND status = ?', ['Scheduled', id, 'Pending']);
    await ppicLog(req, 'CONFIRM', 'MPS', id, { status: 'Draft' }, { status: 'Confirmed' });
    res.json({ message: 'MPS confirmed' });
  } catch (error) { res.status(500).json({ error: 'Failed to confirm MPS' }); }
});

// POST /mps/:id/revert - Revert Confirmed MPS back to Draft
router.post('/mps/:id/revert', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Confirmed') return res.status(400).json({ error: 'Only Confirmed MPS can be reverted to Draft' });

    await dbRun('UPDATE mps_headers SET status = ?, confirmed_by = NULL, confirmed_at = NULL WHERE id = ?', ['Draft', id]);
    await dbRun("UPDATE mps_details SET status = 'Pending' WHERE mps_header_id = ? AND status = 'Scheduled'", [id]);
    await ppicLog(req, 'REVERT', 'MPS', id, { status: 'Confirmed' }, { status: 'Draft' });
    res.json({ message: 'MPS reverted to Draft' });
  } catch (error) {
    console.error('Error reverting MPS:', error);
    res.status(500).json({ error: 'Failed to revert MPS' });
  }
});

// Helper: ISO week → Monday date
const getISOWeekMonday = (year: number, week: number): Date => {
  const jan4 = new Date(year, 0, 4);
  const startOfWeek1 = new Date(jan4);
  startOfWeek1.setDate(jan4.getDate() - (jan4.getDay() || 7) + 1);
  const monday = new Date(startOfWeek1);
  monday.setDate(startOfWeek1.getDate() + (week - 1) * 7);
  return monday;
};
const toDateStr = (d: Date): string => d.toISOString().slice(0, 10);

// GET /mps/:id/details/:detailId/generate-wo/preview — preview WOs that would be created
router.get('/mps/:id/details/:detailId/generate-wo/preview', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });

    const detail = await dbGet(`
      SELECT md.*, p.name as product_name, p.sku as product_sku, u.name as uom_name
      FROM mps_details md
      JOIN products p ON md.product_id = p.id
      LEFT JOIN uom u ON p.unit_of_measure_id = u.id
      WHERE md.id = ? AND md.mps_header_id = ?
    `, [detailId, id]) as any;
    if (!detail) return res.status(404).json({ error: 'MPS detail not found' });

    // Get line process for this product
    const lineInfo = await dbGet(`
      SELECT lp.id as line_id, lp.name as line_name, lp.code as line_code
      FROM line_process_products lpp
      JOIN line_processes lp ON lpp.line_process_id = lp.id AND lp.active = 1
      WHERE lpp.product_id = ? LIMIT 1
    `, [detail.product_id]) as any;

    // Get all weeks with production_qty > 0
    const weeks = await dbAll(`
      SELECT week_number, year, production_qty,
        COALESCE(production_qty, 0) as qty
      FROM mps_week_data
      WHERE mps_detail_id = ? AND COALESCE(production_qty, 0) > 0
      ORDER BY year, week_number
    `, [detailId]) as any[];

    // Get already existing WOs for this detail
    const existingWos = await dbAll(`
      SELECT wo_number, quantity, scheduled_start, scheduled_end, week_number
      FROM work_orders WHERE mps_detail_id = ? ORDER BY scheduled_start
    `, [detailId]) as any[];
    const existingWeeks = new Set(existingWos.map((w: any) => `${w.year || ''}${w.week_number || ''}`));

    const preview = weeks.map((w: any) => {
      const monday = getISOWeekMonday(w.year, w.week_number);
      const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
      const alreadyExists = existingWos.some((e: any) =>
        toDateStr(monday) >= (e.scheduled_start || '') && toDateStr(monday) <= (e.scheduled_end || '')
      );
      return {
        week_number: w.week_number,
        year: w.year,
        production_qty: Number(w.qty),
        scheduled_start: toDateStr(monday),
        scheduled_end: toDateStr(sunday),
        line_name: lineInfo?.line_name || null,
        line_code: lineInfo?.line_code || null,
        already_exists: alreadyExists,
      };
    });

    res.json({
      data: {
        product_name: detail.product_name,
        product_sku: detail.product_sku,
        uom_name: detail.uom_name,
        mps_number: header.mps_number,
        line_name: lineInfo?.line_name || null,
        existing_wos: existingWos,
        preview_weeks: preview,
      }
    });
  } catch (error) {
    console.error('Error previewing WOs:', error);
    res.status(500).json({ error: 'Failed to preview WOs' });
  }
});

// POST /mps/:id/details/:detailId/generate-wo — create WOs (one per selected week)
router.post('/mps/:id/details/:detailId/generate-wo', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    // Optional: selected_weeks = [{week_number, year}] — if empty, generate for all weeks with production_qty > 0
    const { selected_weeks } = req.body;
    const userId = (req as any).user?.id || null;

    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Confirmed') return res.status(400).json({ error: 'MPS must be Confirmed to generate WO' });

    const detail = await dbGet(`
      SELECT md.*, p.name as product_name, p.sku as product_sku, u.name as uom_name
      FROM mps_details md
      JOIN products p ON md.product_id = p.id
      LEFT JOIN uom u ON p.unit_of_measure_id = u.id
      WHERE md.id = ? AND md.mps_header_id = ?
    `, [detailId, id]) as any;
    if (!detail) return res.status(404).json({ error: 'MPS detail not found' });

    // Get line process
    const lineInfo = await dbGet(`
      SELECT lp.id as line_id, lp.name as line_name
      FROM line_process_products lpp
      JOIN line_processes lp ON lpp.line_process_id = lp.id AND lp.active = 1
      WHERE lpp.product_id = ? LIMIT 1
    `, [detail.product_id]) as any;

    // Get weeks to generate
    let weekQuery = `SELECT week_number, year, COALESCE(production_qty, 0) as qty
      FROM mps_week_data WHERE mps_detail_id = ? AND COALESCE(production_qty, 0) > 0
      ORDER BY year, week_number`;
    let weeks = await dbAll(weekQuery, [detailId]) as any[];

    // Filter by selected_weeks if provided
    if (selected_weeks && Array.isArray(selected_weeks) && selected_weeks.length > 0) {
      weeks = weeks.filter((w: any) =>
        selected_weeks.some((s: any) => s.week_number === w.week_number && s.year === w.year)
      );
    }

    if (weeks.length === 0) return res.status(400).json({ error: 'No production weeks with qty > 0 found' });

    const created: any[] = [];
    const skipped: any[] = [];

    for (const w of weeks) {
      const monday = getISOWeekMonday(w.year, w.week_number);
      const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
      const schedStart = toDateStr(monday);
      const schedEnd = toDateStr(sunday);

      // Skip if WO for this week already exists for this mps_detail
      const existing = await dbGet(`
        SELECT id FROM work_orders
        WHERE mps_detail_id = ? AND scheduled_start = ?
      `, [detailId, schedStart]) as any;

      if (existing) {
        skipped.push({ week_number: w.week_number, year: w.year, reason: 'WO already exists' });
        continue;
      }

      // Generate unique WO number
      const woCount = await dbGet('SELECT COUNT(*) as cnt FROM work_orders') as any;
      const woNumber = `WO-${String((woCount?.cnt || 0) + 1).padStart(5, '0')}`;

      const woResult = await dbRun(`
        INSERT INTO work_orders (wo_number, product_id, bom_id, line_process_id, quantity, status, scheduled_start, scheduled_end, so_id, mps_detail_id, created_by, notes, week_number)
        VALUES (?, ?, ?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, ?, ?)
      `, [
        woNumber, detail.product_id, detail.bom_id,
        lineInfo?.line_id || null, Number(w.qty), schedStart, schedEnd,
        detail.so_id, detailId, userId,
        `From MPS ${header.mps_number} W${w.week_number}/${w.year}`,
        w.week_number
      ]);

      await ppicLog(req, 'GENERATE_WO', 'WORK_ORDER', woResult.insertId,
        { mps_detail_id: detailId },
        { wo_number: woNumber, week: w.week_number, year: w.year, qty: w.qty }
      );

      created.push({
        wo_id: woResult.insertId,
        wo_number: woNumber,
        week_number: w.week_number,
        year: w.year,
        quantity: Number(w.qty),
        scheduled_start: schedStart,
        scheduled_end: schedEnd,
        line_name: lineInfo?.line_name || null,
      });
    }

    // Update mps_detail status and link first WO if any created
    if (created.length > 0) {
      await dbRun('UPDATE mps_details SET status = ? WHERE id = ?', ['In Production', detailId]);
      // Link first WO to mps_detail.wo_id for backward compat
      if (!detail.wo_id) {
        await dbRun('UPDATE mps_details SET wo_id = ? WHERE id = ?', [created[0].wo_id, detailId]);
      }
    }

    res.json({
      message: `${created.length} Work Order(s) created, ${skipped.length} skipped`,
      data: { created, skipped }
    });
  } catch (error) {
    console.error('Error generating WO:', error);
    res.status(500).json({ error: 'Failed to generate WO' });
  }
});

// POST /mps/:id/details/:detailId/sync-wo — sync existing DRAFT WO quantities to current MPS values
router.post('/mps/:id/details/:detailId/sync-wo', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;

    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });

    // Get current MPS week data
    const weeks = await dbAll(
      `SELECT week_number, year, COALESCE(production_qty, 0) as qty
       FROM mps_week_data WHERE mps_detail_id = ? ORDER BY year, week_number`,
      [detailId]
    ) as any[];

    const updated: any[] = [];
    const skipped: any[] = [];

    for (const w of weeks) {
      // Find matching DRAFT WO for this week
      const wo = await dbGet(
        `SELECT id, wo_number, quantity, status FROM work_orders
         WHERE mps_detail_id = ? AND week_number = ?`,
        [detailId, w.week_number]
      ) as any;

      if (!wo) {
        skipped.push({ week_number: w.week_number, reason: 'No WO found for this week' });
        continue;
      }

      if (wo.status !== 'DRAFT') {
        skipped.push({ week_number: w.week_number, wo_number: wo.wo_number, reason: `WO status is ${wo.status} (only DRAFT can be synced)` });
        continue;
      }

      const newQty = Number(w.qty);
      if (wo.quantity === newQty) {
        skipped.push({ week_number: w.week_number, wo_number: wo.wo_number, reason: 'Qty unchanged' });
        continue;
      }

      await dbRun(
        `UPDATE work_orders SET quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [newQty, wo.id]
      );

      updated.push({
        wo_id: wo.id,
        wo_number: wo.wo_number,
        week_number: w.week_number,
        old_qty: wo.quantity,
        new_qty: newQty,
      });
    }

    res.json({
      message: `${updated.length} WO(s) synced, ${skipped.length} skipped`,
      data: { updated, skipped },
    });
  } catch (error) {
    console.error('Error syncing WOs:', error);
    res.status(500).json({ error: 'Failed to sync WOs' });
  }
});
// POST /mps/:id/details/:detailId/reset-wo — delete all DRAFT WOs and regenerate from current rec.production
router.post('/mps/:id/details/:detailId/reset-wo', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    const userId = (req as any).user?.id || null;

    const header = await dbGet('SELECT * FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Confirmed') return res.status(400).json({ error: 'MPS must be Confirmed' });

    const detail = await dbGet(`
      SELECT md.*, p.name as product_name, p.sku as product_sku, u.name as uom_name
      FROM mps_details md
      JOIN products p ON md.product_id = p.id
      LEFT JOIN uom u ON p.unit_of_measure_id = u.id
      WHERE md.id = ? AND md.mps_header_id = ?
    `, [detailId, id]) as any;
    if (!detail) return res.status(404).json({ error: 'MPS detail not found' });

    // Get line process
    const lineInfo = await dbGet(`
      SELECT lp.id as line_id, lp.name as line_name
      FROM line_process_products lpp
      JOIN line_processes lp ON lpp.line_process_id = lp.id AND lp.active = 1
      WHERE lpp.product_id = ? LIMIT 1
    `, [detail.product_id]) as any;

    // Step 1: Delete all DRAFT WOs linked to this mps_detail
    const existingDrafts = await dbAll(
      `SELECT id, wo_number, status FROM work_orders WHERE mps_detail_id = ?`,
      [detailId]
    ) as any[];

    const notDraft = existingDrafts.filter((w: any) => w.status !== 'DRAFT');
    if (notDraft.length > 0) {
      return res.status(400).json({
        error: `Cannot reset: ${notDraft.length} WO(s) are not DRAFT (${notDraft.map((w: any) => `${w.wo_number}:${w.status}`).join(', ')})`
      });
    }

    const deletedWos = existingDrafts.map((w: any) => w.wo_number);
    if (existingDrafts.length > 0) {
      await dbRun(`DELETE FROM work_orders WHERE mps_detail_id = ? AND status = 'DRAFT'`, [detailId]);
      // Reset mps_detail status and wo_id
      await dbRun(`UPDATE mps_details SET status = 'Pending', wo_id = NULL WHERE id = ?`, [detailId]);
    }

    // Step 2: Get current rec.production weeks (production_qty > 0)
    const weeks = await dbAll(
      `SELECT week_number, year, COALESCE(production_qty, 0) as qty
       FROM mps_week_data WHERE mps_detail_id = ? AND COALESCE(production_qty, 0) > 0
       ORDER BY year, week_number`,
      [detailId]
    ) as any[];

    if (weeks.length === 0) {
      return res.json({
        message: `Deleted ${deletedWos.length} WO(s). No weeks with rec.production > 0 found — no new WOs created.`,
        data: { deleted: deletedWos, created: [] }
      });
    }

    // Step 3: Recreate WOs from rec.production
    const created: any[] = [];
    for (const w of weeks) {
      const monday = getISOWeekMonday(w.year, w.week_number);
      const sunday = new Date(monday); sunday.setDate(monday.getDate() + 6);
      const schedStart = toDateStr(monday);
      const schedEnd = toDateStr(sunday);

      const woCount = await dbGet('SELECT COUNT(*) as cnt FROM work_orders') as any;
      const woNumber = `WO-${String((woCount?.cnt || 0) + 1).padStart(5, '0')}`;

      const woResult = await dbRun(`
        INSERT INTO work_orders (wo_number, product_id, bom_id, line_process_id, quantity, status, scheduled_start, scheduled_end, so_id, mps_detail_id, created_by, notes, week_number)
        VALUES (?, ?, ?, ?, ?, 'DRAFT', ?, ?, ?, ?, ?, ?, ?)
      `, [
        woNumber, detail.product_id, detail.bom_id,
        lineInfo?.line_id || null, Number(w.qty), schedStart, schedEnd,
        detail.so_id, detailId, userId,
        `Reset from MPS ${header.mps_number} W${w.week_number}/${w.year} (rec.production)`,
        w.week_number
      ]);

      created.push({ wo_number: woNumber, week_number: w.week_number, year: w.year, quantity: Number(w.qty), scheduled_start: schedStart });
    }

    // Update mps_detail status
    if (created.length > 0) {
      await dbRun('UPDATE mps_details SET status = ?, wo_id = ? WHERE id = ?',
        ['In Production', created[0].wo_id || null, detailId]);
      // Link first new WO
      const firstWo = await dbGet(`SELECT id FROM work_orders WHERE mps_detail_id = ? ORDER BY id ASC LIMIT 1`, [detailId]) as any;
      if (firstWo) await dbRun('UPDATE mps_details SET wo_id = ? WHERE id = ?', [firstWo.id, detailId]);
    }

    res.json({
      message: `Reset complete: deleted ${deletedWos.length} old WO(s), created ${created.length} new WO(s) from rec.production`,
      data: { deleted: deletedWos, created }
    });
  } catch (error) {
    console.error('Error resetting WOs:', error);
    res.status(500).json({ error: 'Failed to reset WOs' });
  }
});



// DELETE /mps/:id
router.delete('/mps/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const header = await dbGet('SELECT status FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header) return res.status(404).json({ error: 'MPS not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Only Draft can be deleted' });
    // Delete week data first (cascade should handle, but be safe)
    const detailIds = await dbAll('SELECT id FROM mps_details WHERE mps_header_id = ?', [id]) as any[];
    for (const d of detailIds) {
      await dbRun('DELETE FROM mps_week_data WHERE mps_detail_id = ?', [d.id]);
    }
    await dbRun('DELETE FROM mps_details WHERE mps_header_id = ?', [id]);
    await dbRun('DELETE FROM mps_headers WHERE id = ?', [id]);
    await ppicLog(req, 'DELETE', 'MPS', req.params.id, null, null);
    res.json({ message: 'MPS deleted' });
  } catch (error) { res.status(500).json({ error: 'Failed to delete MPS' }); }
});

// DELETE /mps/:id/details/:detailId
router.delete('/mps/:id/details/:detailId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    const header = await dbGet('SELECT status FROM mps_headers WHERE id = ?', [id]) as any;
    if (!header || header.status !== 'Draft') return res.status(400).json({ error: 'Cannot remove' });
    await dbRun('DELETE FROM mps_week_data WHERE mps_detail_id = ?', [detailId]);
    await dbRun('DELETE FROM mps_details WHERE id = ? AND mps_header_id = ?', [detailId, id]);
    await ppicLog(req, 'DELETE_ITEM', 'MPS_DETAIL', detailId, null, { mps_id: id });
    res.json({ message: 'Item removed from MPS' });
  } catch (error) { res.status(500).json({ error: 'Failed to remove' }); }
});

// GET /pending-orders
router.get('/pending-orders', authMiddleware, async (req: Request, res: Response) => {
  try {
    const soItems = await dbAll(`
      SELECT si.id as so_item_id, si.so_id, si.product_id, si.quantity,
        so.so_number, so.so_date, p.name as product_name, p.sku as product_sku, c.name as customer_name
      FROM so_items si
      JOIN sales_orders so ON si.so_id = so.id
      JOIN products p ON si.product_id = p.id
      LEFT JOIN customers c ON so.customer_id = c.id
      WHERE so.status IN ('OPEN', 'open', 'confirmed', 'CONFIRMED', 'approved', 'APPROVED')
        AND si.id NOT IN (SELECT COALESCE(so_item_id, 0) FROM mps_details WHERE so_item_id IS NOT NULL)
      ORDER BY so.so_date ASC
    `);
    res.json({ data: soItems });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch pending orders' }); }
});
// ==========================================
// MRP — MATERIAL REQUIREMENT PLANNING
// ==========================================

// GET /mps/:id/details/:detailId/mrp - Explode BOM → MRP breakdown
router.get('/mps/:id/details/:detailId/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    
    // Get MPS detail + BOM info
    const detail = await dbGet(`
      SELECT d.*, p.name as product_name, p.sku as product_sku, bh.id as bom_id
      FROM mps_details d
      LEFT JOIN products p ON d.product_id = p.id
      LEFT JOIN bom_headers bh ON d.bom_id = bh.id
      WHERE d.id = ? AND d.mps_header_id = ?
    `, [detailId, id]) as any;
    
    if (!detail) return res.status(404).json({ error: 'MPS detail not found' });
    if (!detail.bom_id) return res.status(400).json({ error: 'No BOM linked to this product' });

    // Get BOM raw materials
    const bomItems = await dbAll(`
      SELECT bd.raw_material_id, bd.quantity as qty_per_unit, bd.unit_of_measure_id,
        p.name as material_name, p.sku as material_sku,
        u.name as uom_name,
        pt.code as product_type_code
      FROM bom_details bd
      JOIN products p ON bd.raw_material_id = p.id
      LEFT JOIN uom u ON bd.unit_of_measure_id = u.id
      LEFT JOIN product_types pt ON p.product_type_id = pt.id
      WHERE bd.bom_header_id = ?
      ORDER BY bd.sequence ASC
    `, [detail.bom_id]) as any[];

    // Get MPS weekly production data (fg_qty drives gross requirements)
    const mpsWeeks = await dbAll(`
      SELECT * FROM mps_week_data WHERE mps_detail_id = ? ORDER BY year, week_number
    `, [detailId]) as any[];

    // Get saved MRP planned receipts
    const mrpData = await dbAll(`
      SELECT * FROM mrp_week_data WHERE mps_detail_id = ?
    `, [detailId]) as any[];

    // Generate week columns
    const numWeeks = 12;
    const now = new Date();
    const currentWeek = getWeekNumber(now);
    const currentYear = now.getFullYear();
    const weekColumns: any[] = [];
    for (let i = 0; i < numWeeks; i++) {
      let wk = currentWeek + i;
      let yr = currentYear;
      if (wk > 52) { wk -= 52; yr++; }
      const range = getWeekDateRange(yr, wk);
      weekColumns.push({ week: wk, year: yr, label: `W${wk}`, dateRange: `${range.start}-${range.end}` });
    }

    // Fetch real inventory stock for all BOM materials at once
    const matIds = bomItems.map((b: any) => b.raw_material_id);
    const matPlaceholders = matIds.map(() => '?').join(',');
    const inventoryRows = matIds.length > 0
      ? await dbAll(
          `SELECT product_id, COALESCE(SUM(quantity),0) as stock
           FROM inventory_stocks
           WHERE product_id IN (${matPlaceholders}) AND quantity > 0
           GROUP BY product_id`,
          matIds
        ) as any[]
      : [];
    const stockMap = new Map(inventoryRows.map((r: any) => [r.product_id, Number(r.stock)]));

    // Fetch lead time & unit price from vendor prices (best selected, or min price)
    const vendorRows = matIds.length > 0
      ? await dbAll(
          `SELECT material_id,
            COALESCE(MIN(CASE WHEN is_selected=1 THEN lead_time_days END), MIN(lead_time_days)) as lead_time_days,
            COALESCE(MIN(CASE WHEN is_selected=1 THEN price END), MIN(price)) as unit_price,
            COALESCE(MIN(CASE WHEN is_selected=1 THEN vendor_name END), MIN(vendor_name)) as vendor_name
           FROM material_vendor_prices
           WHERE material_id IN (${matPlaceholders})
           GROUP BY material_id`,
          matIds
        ) as any[]
      : [];
    const vendorMap = new Map(vendorRows.map((r: any) => [r.material_id, r]));

    // For each BOM material, calculate MRP
    const materials = bomItems.map((bom: any) => {
      const matId = bom.raw_material_id;
      const qtyPerUnit = Number(bom.qty_per_unit) || 0;

      // Calculate per-week data
      const weeks = weekColumns.map((wc: any) => {
        // Gross requirement = MPS production_qty × BOM qty_per_unit
        // production_qty = planned production (set by user in MPS "Rec. Production" row)
        const mpsWeek = mpsWeeks.find((w: any) => w.week_number === wc.week && w.year === wc.year);
        const productionQty = Number(mpsWeek?.production_qty || 0);
        const grossReq = productionQty * qtyPerUnit;

        // Planned order receipt (from saved MRP data or 0)
        const mrpWeek = mrpData.find((m: any) => m.material_id === matId && m.week_number === wc.week && m.year === wc.year);
        const plannedReceipt = Number(mrpWeek?.planned_order_receipt || 0);

        return {
          week_number: wc.week,
          year: wc.year,
          gross_requirements: Math.round(grossReq * 100) / 100,
          planned_order_receipt: plannedReceipt,
          // net_requirements and projected_on_hand calculated on frontend
        };
      });

      const vendorInfo = vendorMap.get(matId);
      // lead_time_days → weeks (ceil, default 2 weeks)
      const leadTimeWeeks = vendorInfo?.lead_time_days
        ? Math.max(1, Math.ceil(Number(vendorInfo.lead_time_days) / 7))
        : 2;

      return {
        material_id: matId,
        material_name: bom.material_name,
        material_sku: bom.material_sku,
        uom_name: bom.uom_name || 'KG',
        product_type_code: bom.product_type_code,
        qty_per_unit: qtyPerUnit,
        lead_time: leadTimeWeeks,
        lead_time_days: vendorInfo?.lead_time_days || null,
        unit_price: vendorInfo?.unit_price || null,
        vendor_name: vendorInfo?.vendor_name || null,
        first_stock: stockMap.get(matId) || 0,
        weeks
      };
    });

    res.json({
      data: {
        product: { id: detail.product_id, name: detail.product_name, sku: detail.product_sku },
        bom_id: detail.bom_id,
        materials,
        weekColumns
      }
    });
  } catch (error) {
    console.error('Error fetching MRP:', error);
    res.status(500).json({ error: 'Failed to fetch MRP data' });
  }
});

// PUT /mps/:id/details/:detailId/mrp - Save MRP planned order receipts
router.put('/mps/:id/details/:detailId/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { detailId } = req.params;
    const { entries } = req.body; // [{ material_id, week_number, year, planned_order_receipt }]

    for (const entry of (entries || [])) {
      const existing = await dbGet(
        'SELECT id FROM mrp_week_data WHERE mps_detail_id = ? AND material_id = ? AND year = ? AND week_number = ?',
        [detailId, entry.material_id, entry.year, entry.week_number]
      );
      if (existing) {
        await dbRun(
          'UPDATE mrp_week_data SET planned_order_receipt = ? WHERE mps_detail_id = ? AND material_id = ? AND year = ? AND week_number = ?',
          [entry.planned_order_receipt || 0, detailId, entry.material_id, entry.year, entry.week_number]
        );
      } else {
        await dbRun(
          'INSERT INTO mrp_week_data (mps_detail_id, material_id, week_number, year, planned_order_receipt) VALUES (?, ?, ?, ?, ?)',
          [detailId, entry.material_id, entry.week_number, entry.year, entry.planned_order_receipt || 0]
        );
      }
    }

    res.json({ message: 'MRP data saved' });
  } catch (error) {
    console.error('Error saving MRP:', error);
    res.status(500).json({ error: 'Failed to save MRP data' });
  }
});

// POST /mps/:id/details/:detailId/mrp/generate-pr - Generate Purchase Request from MRP Net Requirements
router.post('/mps/:id/details/:detailId/mrp/generate-pr', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id, detailId } = req.params;
    const { material_net_reqs, needed_by_week, needed_by_year } = req.body;
    // material_net_reqs: [{ material_id, material_name, uom_name, net_req_qty }]

    if (!material_net_reqs || material_net_reqs.length === 0) {
      return res.status(400).json({ error: 'No materials with net requirements' });
    }

    // Get MPS detail for context
    const detail = await dbGet(`
      SELECT md.*, p.name as product_name, mh.mps_number
      FROM mps_details md
      JOIN products p ON md.product_id = p.id
      JOIN mps_headers mh ON md.mps_header_id = mh.id
      WHERE md.id = ? AND md.mps_header_id = ?
    `, [detailId, id]) as any;
    if (!detail) return res.status(404).json({ error: 'MPS detail not found' });

    // Generate PR number
    const prCount = await dbGet('SELECT COUNT(*) as cnt FROM purchase_requests', []) as any;
    const prNum = `PR-MRP-${new Date().getFullYear()}-${String(Number(prCount.cnt) + 1).padStart(4, '0')}`;

    // Calculate needed_by date from week/year
    let neededByDate = null;
    if (needed_by_week && needed_by_year) {
      const jan1 = new Date(needed_by_year, 0, 1);
      const dayOffset = (needed_by_week - 1) * 7;
      neededByDate = new Date(jan1.getTime() + dayOffset * 86400000).toISOString().split('T')[0];
    }

    // Get requestor from auth token
    const requestorId = (req as any).user?.id || null;

    // Create PR header
    const prResult = await dbRun(`
      INSERT INTO purchase_requests 
        (pr_number, requestor_id, status, approval_required, notes, request_date, needed_by)
      VALUES (?, ?, 'DRAFT', 1, ?, CURDATE(), ?)
    `, [
      prNum,
      requestorId,
      `Auto-generated from MPS MRP: ${detail.mps_number} — ${detail.product_name}`,
      neededByDate
    ]);
    const prId = prResult.insertId;

    // Create PR items for each material with net_req > 0
    for (const mat of material_net_reqs) {
      if (Number(mat.net_req_qty) <= 0) continue;
      // Get product_id of the raw material (material_id is already product_id)
      await dbRun(`
        INSERT INTO purchase_request_items (purchase_request_id, product_id, quantity, notes)
        VALUES (?, ?, ?, ?)
      `, [
        prId,
        mat.material_id,
        Math.ceil(Number(mat.net_req_qty) * 100) / 100,
        `MRP Net Req — ${detail.product_name} (${detail.mps_number})`
      ]);
    }

    await ppicLog(req, 'GENERATE_PR', 'MPS_MRP', detailId, null, {
      pr_number: prNum, pr_id: prId, mps_id: id, materials_count: material_net_reqs.length
    });

    res.json({
      message: `PR ${prNum} created successfully`,
      pr_id: prId,
      pr_number: prNum,
      items_created: material_net_reqs.filter((m: any) => Number(m.net_req_qty) > 0).length
    });
  } catch (error) {
    console.error('Error generating PR from MRP:', error);
    res.status(500).json({ error: 'Failed to generate PR' });
  }
});

// ==========================================
// STANDALONE MRP — Aggregated across ALL confirmed MPS
// ==========================================

// GET /mrp - Standalone MRP: aggregate gross requirements per unique raw material across all confirmed MPS
router.get('/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentWeek = getWeekNumber(now);
    const year = Number(req.query.year) || currentYear;

    // Generate 12 week columns from current week
    const numWeeks = 12;
    const weekColumns: any[] = [];
    for (let i = 0; i < numWeeks; i++) {
      let wk = currentWeek + i;
      let yr = currentYear;
      if (wk > 52) { wk -= 52; yr++; }
      const range = getWeekDateRange(yr, wk);
      weekColumns.push({ week: wk, year: yr, label: `W${wk}`, dateRange: `${range.start}-${range.end}` });
    }

    // 1. Get ALL MPS headers (Draft + Confirmed) for the requested year
    const mpsHeaders = await dbAll(
      `SELECT id FROM mps_headers WHERE status IN ('Draft', 'Confirmed') AND period_year = ?`,
      [year]
    ) as any[];

    if (mpsHeaders.length === 0) {
      return res.json({ data: { materials: [], weekColumns } });
    }

    const headerIds = mpsHeaders.map((h: any) => h.id);
    const headerPlaceholders = headerIds.map(() => '?').join(',');

    // 2. Get ALL MPS details for those headers (with BOM info)
    const allDetails = await dbAll(`
      SELECT d.id as detail_id, d.product_id, d.bom_id
      FROM mps_details d
      WHERE d.mps_header_id IN (${headerPlaceholders}) AND d.bom_id IS NOT NULL
    `, headerIds) as any[];

    if (allDetails.length === 0) {
      return res.json({ data: { materials: [], weekColumns } });
    }

    const detailIds = allDetails.map((d: any) => d.detail_id);
    const detailPlaceholders = detailIds.map(() => '?').join(',');

    // 3. Get ALL MPS weekly production data for those details
    const allMpsWeeks = await dbAll(`
      SELECT * FROM mps_week_data WHERE mps_detail_id IN (${detailPlaceholders}) ORDER BY year, week_number
    `, detailIds) as any[];

    // 4. Get ALL unique BOM IDs, then load BOM details (raw materials)
    const bomIds = [...new Set(allDetails.map((d: any) => d.bom_id))];
    const bomPlaceholders = bomIds.map(() => '?').join(',');

    const allBomItems = await dbAll(`
      SELECT bd.bom_header_id, bd.raw_material_id, bd.quantity as qty_per_unit, bd.unit_of_measure_id,
        p.name as material_name, p.sku as material_sku,
        u.name as uom_name,
        pt.code as product_type_code
      FROM bom_details bd
      JOIN products p ON bd.raw_material_id = p.id
      LEFT JOIN uom u ON bd.unit_of_measure_id = u.id
      LEFT JOIN product_types pt ON p.product_type_id = pt.id
      WHERE bd.bom_header_id IN (${bomPlaceholders})
      ORDER BY bd.sequence ASC
    `, bomIds) as any[];

    // 5. Load saved standalone MRP data (mps_detail_id = 0 for global)
    const savedMrpData = await dbAll(`
      SELECT * FROM mrp_week_data WHERE mps_detail_id = 0
    `) as any[];

    // 6. Also load per-detail MRP data to aggregate
    const perDetailMrpData = await dbAll(`
      SELECT * FROM mrp_week_data WHERE mps_detail_id IN (${detailPlaceholders})
    `, detailIds) as any[];

    // 7. Aggregate gross requirements per unique raw material per week
    // Map: material_id -> { info, weekMap: { "wk-yr" -> gross_req } }
    const materialMap: Record<number, {
      material_id: number;
      material_name: string;
      material_sku: string;
      uom_name: string;
      product_type_code: string;
      weekGross: Record<string, number>;
    }> = {};

    for (const detail of allDetails) {
      const bomItems = allBomItems.filter((b: any) => b.bom_header_id === detail.bom_id);
      const detailWeeks = allMpsWeeks.filter((w: any) => w.mps_detail_id === detail.detail_id);

      for (const bom of bomItems) {
        const matId = bom.raw_material_id;
        const qtyPerUnit = Number(bom.qty_per_unit) || 0;

        if (!materialMap[matId]) {
          materialMap[matId] = {
            material_id: matId,
            material_name: bom.material_name,
            material_sku: bom.material_sku,
            uom_name: bom.uom_name,
            product_type_code: bom.product_type_code,
            weekGross: {}
          };
        }

        // For each week column, add this detail's contribution to gross requirements
        for (const wc of weekColumns) {
          const key = `${wc.week}-${wc.year}`;
          const mpsWeek = detailWeeks.find((w: any) => w.week_number === wc.week && w.year === wc.year);
          // Use production_qty (Rec. Production row in MPS) — same as per-item MRP
          const productionQty = Number(mpsWeek?.production_qty || 0);
          const grossReq = productionQty * qtyPerUnit;

          if (!materialMap[matId].weekGross[key]) {
            materialMap[matId].weekGross[key] = 0;
          }
          materialMap[matId].weekGross[key] += grossReq;
        }
      }
    }

    // 8a. Load actual inventory stock for all unique materials
    const uniqueMatIds = Object.keys(materialMap).map(Number);
    const matStockRows = uniqueMatIds.length > 0
      ? await dbAll(
          `SELECT product_id, COALESCE(SUM(quantity),0) as stock
           FROM inventory_stocks WHERE product_id IN (${uniqueMatIds.map(()=>'?').join(',')}) AND quantity > 0
           GROUP BY product_id`,
          uniqueMatIds
        ) as any[]
      : [];
    const stockMap2 = new Map(matStockRows.map((r: any) => [r.product_id, Number(r.stock)]));

    // 8b. Load vendor lead_time for all unique materials
    const vendorRows2 = uniqueMatIds.length > 0
      ? await dbAll(
          `SELECT material_id,
            COALESCE(MIN(CASE WHEN is_selected=1 THEN lead_time_days END), MIN(lead_time_days)) as lead_time_days
           FROM material_vendor_prices WHERE material_id IN (${uniqueMatIds.map(()=>'?').join(',')})
           GROUP BY material_id`,
          uniqueMatIds
        ) as any[]
      : [];
    const vendorMap2 = new Map(vendorRows2.map((r: any) => [r.material_id, r]));

    // 9. Build final materials array with weekly data
    const materials = Object.values(materialMap).map((mat) => {
      const weeks = weekColumns.map((wc) => {
        const key = `${wc.week}-${wc.year}`;
        const grossReq = mat.weekGross[key] || 0;

        // Check standalone saved data first (mps_detail_id=0), fallback to 0
        const savedWeek = savedMrpData.find(
          (m: any) => m.material_id === mat.material_id && m.week_number === wc.week && m.year === wc.year
        );

        const plannedReceipt = Number(savedWeek?.planned_order_receipt || 0);
        const plannedRelease = Number(savedWeek?.planned_order_release || 0);

        return {
          week_number: wc.week,
          year: wc.year,
          gross_requirements: Math.round(grossReq * 100) / 100,
          planned_order_receipt: plannedReceipt,
          planned_order_release: plannedRelease
        };
      });

      const vendorInfo2 = vendorMap2.get(mat.material_id);
      const leadTimeWeeks = vendorInfo2?.lead_time_days
        ? Math.max(1, Math.ceil(Number(vendorInfo2.lead_time_days) / 7))
        : 2;

      return {
        material_id: mat.material_id,
        material_name: mat.material_name,
        material_sku: mat.material_sku,
        uom_name: mat.uom_name,
        product_type_code: mat.product_type_code,
        lead_time: leadTimeWeeks,
        first_stock: stockMap2.get(mat.material_id) || 0,
        order_quantity: 0,
        weeks
      };
    });

    res.json({ data: { materials, weekColumns } });

  } catch (error) {
    console.error('Error fetching standalone MRP:', error);
    res.status(500).json({ error: 'Failed to fetch standalone MRP data' });
  }
});

// PUT /mrp - Save standalone MRP planned_order_release & planned_order_receipt (global, mps_detail_id=0)
router.put('/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { entries } = req.body; // [{ material_id, week_number, year, planned_order_receipt, planned_order_release }]

    for (const entry of (entries || [])) {
      const existing = await dbGet(
        'SELECT id FROM mrp_week_data WHERE mps_detail_id = 0 AND material_id = ? AND year = ? AND week_number = ?',
        [entry.material_id, entry.year, entry.week_number]
      );

      if (existing) {
        await dbRun(
          'UPDATE mrp_week_data SET planned_order_receipt = ?, planned_order_release = ? WHERE mps_detail_id = 0 AND material_id = ? AND year = ? AND week_number = ?',
          [entry.planned_order_receipt || 0, entry.planned_order_release || 0, entry.material_id, entry.year, entry.week_number]
        );
      } else {
        await dbRun(
          'INSERT INTO mrp_week_data (mps_detail_id, material_id, week_number, year, planned_order_receipt, planned_order_release) VALUES (0, ?, ?, ?, ?, ?)',
          [entry.material_id, entry.week_number, entry.year, entry.planned_order_receipt || 0, entry.planned_order_release || 0]
        );
      }
    }

    await ppicLog(req, 'SAVE', 'MRP', null, null, { entries_count: (entries || []).length });
    res.json({ message: 'Standalone MRP data saved' });
  } catch (error) {
    console.error('Error saving standalone MRP:', error);
    res.status(500).json({ error: 'Failed to save standalone MRP data' });
  }
});

// POST /mrp/generate-pr - Generate Purchase Request from MRP Net Requirements
router.post('/mrp/generate-pr', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { materials, year, notes } = req.body;
    // materials: [{ material_id, material_name, uom_name, total_net_requirement, lead_time }]

    if (!materials || !Array.isArray(materials) || materials.length === 0) {
      return res.status(400).json({ error: 'No materials provided. Select materials with net requirements > 0.' });
    }

    // Filter only materials with actual net requirements
    const validMaterials = materials.filter((m: any) => Number(m.total_net_requirement) > 0);
    if (validMaterials.length === 0) {
      return res.status(400).json({ error: 'No materials have net requirements > 0.' });
    }

    const userId = (req as any).user?.userId || null;

    // Generate PR number: PR-MRP-YYYYMMDD-XXX
    const now = new Date();
    const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
    const rand = Math.floor(100 + Math.random() * 900);
    const prNumber = `PR-MRP-${datePart}-${rand}`;

    // Calculate needed_by based on max lead time
    const maxLeadTime = Math.max(...validMaterials.map((m: any) => Number(m.lead_time) || 2));
    const neededBy = new Date();
    neededBy.setDate(neededBy.getDate() + maxLeadTime * 7); // lead_time in weeks

    // Build notes with MRP source info
    const prNotes = [
      notes || '',
      `[Auto-generated from MRP Year ${year || now.getFullYear()}]`,
      `Materials: ${validMaterials.length} items`,
      `Generated: ${now.toISOString().slice(0, 19).replace('T', ' ')}`
    ].filter(Boolean).join('\n');

    // Create the Purchase Request
    const prResult = await dbRun(
      `INSERT INTO purchase_requests (pr_number, requestor_id, status, notes, request_date, needed_by)
       VALUES (?, ?, 'DRAFT', ?, ?, ?)`,
      [
        prNumber,
        userId,
        prNotes,
        now.toISOString().slice(0, 10),
        neededBy.toISOString().slice(0, 10)
      ]
    );
    const prId = prResult.insertId;

    // Create PR items for each material
    let itemCount = 0;
    const skipped: string[] = [];
    for (const mat of validMaterials) {
      const qty = Number(mat.total_net_requirement) || 0;
      if (qty <= 0) continue;

      try {
        await dbRun(
          `INSERT INTO purchase_request_items (purchase_request_id, product_id, quantity, notes)
           VALUES (?, ?, ?, ?)`,
          [
            prId,
            mat.material_id,
            qty,
            `MRP Net Req | Lead Time: ${mat.lead_time || 2} weeks | UOM: ${mat.uom_name || '-'}`
          ]
        );
        itemCount++;
      } catch (itemErr: any) {
        console.warn(`⚠️ Skipped material ${mat.material_name} (ID=${mat.material_id}): ${itemErr.message}`);
        skipped.push(`${mat.material_name} (ID=${mat.material_id})`);
      }
    }

    console.log(`✅ PR generated from MRP: ${prNumber} with ${itemCount} items (PR ID: ${prId})`);

    await ppicLog(req, 'GENERATE_PR', 'MRP', prId, null, { pr_number: prNumber, item_count: itemCount });
    res.status(201).json({
      success: true,
      message: `Purchase Request ${prNumber} created with ${itemCount} materials` + (skipped.length > 0 ? ` (${skipped.length} skipped)` : ''),
      data: {
        pr_id: prId,
        pr_number: prNumber,
        item_count: itemCount,
        needed_by: neededBy.toISOString().slice(0, 10),
        skipped
      }
    });
  } catch (error: any) {
    console.error('Error generating PR from MRP:', error);
    if (error.message?.includes('UNIQUE')) {
      return res.status(400).json({ error: 'PR number conflict. Please try again.' });
    }
    res.status(500).json({ error: 'Failed to generate Purchase Request from MRP' });
  }
});

// ============================================================
// SALES FORECAST — Sister Company C2509 Integration
// ============================================================

// GET /forecast-brands - List all brands
router.get('/forecast-brands', authMiddleware, async (_req: Request, res: Response) => {
  try {
    const brands = await dbAll(`
      SELECT fb.*, p.name as product_name, p.sku as product_sku
      FROM forecast_brands fb
      LEFT JOIN products p ON fb.product_id = p.id
      ORDER BY fb.brand_name ASC
    `);
    res.json(brands);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch forecast brands' });
  }
});

// POST /forecast-brands - Create brand
router.post('/forecast-brands', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { brand_name, type, product_id, conversion_rate, conversion_uom, notes } = req.body;
    if (!brand_name) return res.status(400).json({ error: 'Brand name is required' });
    if (!product_id) return res.status(400).json({ error: 'Product is required' });
    const result = await dbRun(
      'INSERT INTO forecast_brands (brand_name, type, product_id, conversion_rate, conversion_uom, notes) VALUES (?, ?, ?, ?, ?, ?)',
      [brand_name, type || 'Brand', product_id, conversion_rate || 1, conversion_uom || 'ltr', notes || null]
    );
    res.json({ id: result.insertId, message: 'Brand created' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create brand' });
  }
});

// PUT /forecast-brands/:id - Update brand
router.put('/forecast-brands/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { brand_name, type, product_id, conversion_rate, conversion_uom, notes, is_active } = req.body;
    await dbRun(
      'UPDATE forecast_brands SET brand_name=?, type=?, product_id=?, conversion_rate=?, conversion_uom=?, notes=?, is_active=? WHERE id=?',
      [brand_name, type || 'Brand', product_id, conversion_rate, conversion_uom || 'ltr', notes, is_active ?? true, req.params.id]
    );
    res.json({ message: 'Brand updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update brand' });
  }
});

// DELETE /forecast-brands/:id
router.delete('/forecast-brands/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM forecast_brands WHERE id = ?', [req.params.id]);
    res.json({ message: 'Brand deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete brand' });
  }
});

// GET /forecasts - List forecast headers
router.get('/forecasts', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { year, month } = req.query;
    let sql = 'SELECT * FROM forecast_headers';
    const params: any[] = [];
    if (year && month) {
      sql += ' WHERE period_year = ? AND period_month = ?';
      params.push(year, month);
    }
    sql += ' ORDER BY period_year DESC, period_month DESC';
    const headers = await dbAll(sql, params);
    res.json(headers);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch forecasts' });
  }
});

// POST /forecasts - Create new forecast
router.post('/forecasts', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { period_year, period_month, notes } = req.body;
    // Check duplicate
    const existing = await dbGet(
      'SELECT id FROM forecast_headers WHERE period_year = ? AND period_month = ?',
      [period_year, period_month]
    );
    if (existing) return res.status(400).json({ error: 'Forecast for this period already exists' });

    const fcNum = `FC-${period_year}-${String(period_month).padStart(2, '0')}`;
    const result = await dbRun(
      'INSERT INTO forecast_headers (forecast_number, period_year, period_month, notes) VALUES (?, ?, ?, ?)',
      [fcNum, period_year, period_month, notes || null]
    );
    await ppicLog(req, 'CREATE', 'FORECAST', result.insertId, null, { forecast_number: fcNum, period_year, period_month });
    res.json({ id: result.insertId, forecast_number: fcNum });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create forecast' });
  }
});

// GET /forecasts/:id - Get forecast with grid data
router.get('/forecasts/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const header = await dbGet('SELECT * FROM forecast_headers WHERE id = ?', [req.params.id]);
    if (!header) return res.status(404).json({ error: 'Forecast not found' });

    const brands = await dbAll(`
      SELECT fb.*, p.name as product_name, p.sku as product_sku
      FROM forecast_brands fb
      LEFT JOIN products p ON fb.product_id = p.id
      WHERE fb.is_active = 1
      ORDER BY fb.brand_name ASC
    `) as any[];

    const weekData = await dbAll(
      'SELECT * FROM forecast_week_data WHERE forecast_header_id = ?',
      [req.params.id]
    ) as any[];

    // Build week columns based on the forecast's period (weeks within that month)
    const hdr = header as any;
    const periodYear = hdr.period_year;
    const periodMonth = hdr.period_month;
    const firstDay = new Date(periodYear, periodMonth - 1, 1);
    const lastDay = new Date(periodYear, periodMonth, 0);
    const weekColumns: { week: number; year: number; start: string; end: string }[] = [];
    const seenWeeks = new Set<string>();
    for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
      const wk = getWeekNumber(d);
      const yr = d.getFullYear();
      const key = `${yr}-W${wk}`;
      if (!seenWeeks.has(key)) {
        seenWeeks.add(key);
        const range = getWeekDateRange(yr, wk);
        weekColumns.push({ week: wk, year: yr, start: range.start, end: range.end });
      }
    }

    // Organize week data by brand
    const brandData = brands.map((brand: any) => {
      const weeks: any = {};
      for (const wc of weekColumns) {
        const k = `${wc.week}:${wc.year}`;
        const wData = weekData.find(
          (w: any) => w.brand_id === brand.id && w.week_number === wc.week && w.year === wc.year
        );
        weeks[k] = {
          forecast_qty: Number(wData?.forecast_qty || 0),
          product_qty: Number(wData?.product_qty || 0)
        };
      }
      return { ...brand, weeks };
    });

    res.json({ header, brands: brandData, weekColumns });
  } catch (error) {
    console.error('Error fetching forecast:', error);
    res.status(500).json({ error: 'Failed to fetch forecast' });
  }
});

// POST /forecasts/:id/generate-grid - Generate 12-week grid for all active brands (supports adding new brands)
router.post('/forecasts/:id/generate-grid', authMiddleware, async (req: Request, res: Response) => {
  try {
    const header = await dbGet('SELECT * FROM forecast_headers WHERE id = ?', [req.params.id]) as any;
    if (!header) return res.status(404).json({ error: 'Forecast not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Can only generate grid for Draft forecasts' });

    const brands = await dbAll('SELECT * FROM forecast_brands WHERE is_active = 1') as any[];
    if (brands.length === 0) return res.status(400).json({ error: 'No active brands found. Please add brands first.' });

    // Get existing brand_ids already in grid (so we don't overwrite their data)
    const existingRows = await dbAll(
      'SELECT DISTINCT brand_id FROM forecast_week_data WHERE forecast_header_id = ?',
      [req.params.id]
    ) as any[];
    const existingBrandIds = new Set(existingRows.map((r: any) => r.brand_id));

    // Only add brands NOT yet in the grid
    const newBrands = brands.filter((b: any) => !existingBrandIds.has(b.id));

    // Generate weeks for this header's month
    const firstDay = new Date(header.period_year, header.period_month - 1, 1);
    const lastDay = new Date(header.period_year, header.period_month, 0);
    const monthWeeks: { week: number; year: number }[] = [];
    const seenWks = new Set<string>();
    for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
      const wk = getWeekNumber(d);
      const yr = d.getFullYear();
      const key = `${yr}-W${wk}`;
      if (!seenWks.has(key)) { seenWks.add(key); monthWeeks.push({ week: wk, year: yr }); }
    }

    for (const brand of newBrands) {
      for (const mw of monthWeeks) {
        await dbRun(
          'INSERT IGNORE INTO forecast_week_data (forecast_header_id, brand_id, week_number, year, forecast_qty, product_qty) VALUES (?, ?, ?, ?, 0, 0)',
          [req.params.id, brand.id, mw.week, mw.year]
        );
      }
    }

    if (newBrands.length === 0) {
      res.json({ message: `Grid already up to date. All ${brands.length} active brands are in the grid.`, added: 0 });
    } else {
      res.json({
        message: `Added ${newBrands.length} new brand(s): ${newBrands.map((b: any) => b.brand_name).join(', ')}`,
        added: newBrands.length,
        total_brands: brands.length
      });
    }
  } catch (error) {
    console.error('Error generating forecast grid:', error);
    res.status(500).json({ error: 'Failed to generate grid' });
  }
});

// PUT /forecasts/:id/week-data - Save weekly forecast data (batch)
router.put('/forecasts/:id/week-data', authMiddleware, async (req: Request, res: Response) => {
  try {
    const header = await dbGet('SELECT * FROM forecast_headers WHERE id = ?', [req.params.id]) as any;
    if (!header) return res.status(404).json({ error: 'Forecast not found' });
    if (header.status !== 'Draft') return res.status(400).json({ error: 'Cannot edit confirmed forecast' });

    const { data } = req.body; // Array of { brand_id, week_number, year, forecast_qty }
    if (!Array.isArray(data)) return res.status(400).json({ error: 'Data must be an array' });

    // Get brand conversion rates
    const brands = await dbAll('SELECT id, conversion_rate FROM forecast_brands') as any[];
    const rateMap = new Map(brands.map((b: any) => [b.id, Number(b.conversion_rate)]));

    for (const item of data) {
      const rate = rateMap.get(item.brand_id) || 1;
      const productQty = Math.round(Number(item.forecast_qty) * rate * 100) / 100;

      await dbRun(`
        INSERT INTO forecast_week_data (forecast_header_id, brand_id, week_number, year, forecast_qty, product_qty)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE forecast_qty = VALUES(forecast_qty), product_qty = VALUES(product_qty)
      `, [req.params.id, item.brand_id, item.week_number, item.year, item.forecast_qty, productQty]);
    }

    await ppicLog(req, 'SAVE_WEEK_DATA', 'FORECAST', req.params.id, null, { entries_count: data.length });
    res.json({ message: 'Forecast data saved' });
  } catch (error) {
    console.error('Error saving forecast data:', error);
    res.status(500).json({ error: 'Failed to save forecast data' });
  }
});

// PUT /forecasts/:id/status - Change status
router.put('/forecasts/:id/status', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { status } = req.body;
    if (!['Draft', 'Confirmed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
    await dbRun('UPDATE forecast_headers SET status = ? WHERE id = ?', [status, req.params.id]);
    await ppicLog(req, status === 'Confirmed' ? 'CONFIRM' : 'REVERT', 'FORECAST', req.params.id, null, { status });
    res.json({ message: `Forecast status changed to ${status}` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// DELETE /forecasts/:id
router.delete('/forecasts/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM forecast_headers WHERE id = ?', [req.params.id]);
    await ppicLog(req, 'DELETE', 'FORECAST', req.params.id, null, null);
  res.json({ message: 'Forecast deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete forecast' });
  }
});

// POST /forecasts/:id/push-to-mps - Push forecast data into MPS forecast_qty row
router.post('/forecasts/:id/push-to-mps', authMiddleware, async (req: Request, res: Response) => {
  try {
    const forecast = await dbGet('SELECT * FROM forecast_headers WHERE id = ?', [req.params.id]) as any;
    if (!forecast) return res.status(404).json({ error: 'Forecast not found' });

    // Get all forecast week data grouped by product_id and week
    const forecastData = await dbAll(`
      SELECT fb.product_id, fw.week_number, fw.year, SUM(fw.product_qty) as total_qty
      FROM forecast_week_data fw
      JOIN forecast_brands fb ON fw.brand_id = fb.id
      WHERE fw.forecast_header_id = ? AND fb.product_id IS NOT NULL
      GROUP BY fb.product_id, fw.week_number, fw.year
    `, [req.params.id]) as any[];

    if (forecastData.length === 0) return res.status(400).json({ error: 'No forecast data to push' });

    // Find active MPS (Draft preferred, then any) for the same period
    let mps = await dbGet(
      `SELECT * FROM mps_headers WHERE period_year = ? AND period_month = ? AND status = 'Draft' ORDER BY id DESC LIMIT 1`,
      [forecast.period_year, forecast.period_month]
    ) as any;
    if (!mps) {
      mps = await dbGet(
        `SELECT * FROM mps_headers WHERE status = 'Draft' ORDER BY id DESC LIMIT 1`
      ) as any;
    }
    if (!mps) return res.status(400).json({ error: 'No Draft MPS found. Create an MPS first.' });

    // Get unique product_ids from forecast
    const productIds = [...new Set(forecastData.map((f: any) => f.product_id))];
    let updated = 0;
    let created = 0;

    for (const productId of productIds) {
      // Find or create MPS detail for this product
      let mpsDetail = await dbGet(
        'SELECT id FROM mps_details WHERE mps_header_id = ? AND product_id = ?',
        [mps.id, productId]
      ) as any;

      if (!mpsDetail) {
        // Auto-create MPS detail for this product
        const product = await dbGet('SELECT id, name FROM products WHERE id = ?', [productId]) as any;
        if (!product) continue;

        const bom = await dbGet(
          "SELECT id FROM bom_headers WHERE product_id = ? AND status = 'ACTIVE' LIMIT 1",
          [productId]
        ) as any;

        const result = await dbRun(
          'INSERT INTO mps_details (mps_header_id, product_id, bom_id, demand_qty, status, lead_time_weeks) VALUES (?, ?, ?, 0, \'Pending\', 1)',
          [mps.id, productId, bom?.id || null]
        );
        mpsDetail = { id: result.insertId };
        created++;

        // Initialize 12-week grid for this new mps_detail
        const now = new Date();
        const currentWeek = getWeekNumber(now);
        const currentYear = now.getFullYear();
        for (let i = 0; i < 12; i++) {
          let wk = currentWeek + i;
          let yr = currentYear;
          if (wk > 52) { wk -= 52; yr++; }
          await dbRun(
            'INSERT IGNORE INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty, production_qty) VALUES (?, ?, ?, 0, 0, 0, 0, 0)',
            [mpsDetail.id, wk, yr]
          );
        }
      }

      // Update forecast_qty for matching weeks
      const productWeeks = forecastData.filter((f: any) => f.product_id === productId);
      for (const pw of productWeeks) {
        const existingWeek = await dbGet(
          'SELECT id FROM mps_week_data WHERE mps_detail_id = ? AND year = ? AND week_number = ?',
          [mpsDetail.id, pw.year, pw.week_number]
        ) as any;

        if (existingWeek) {
          await dbRun(
            'UPDATE mps_week_data SET forecast_qty = ? WHERE id = ?',
            [pw.total_qty, existingWeek.id]
          );
        } else {
          await dbRun(
            'INSERT INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty, production_qty) VALUES (?, ?, ?, ?, 0, 0, 0, 0)',
            [mpsDetail.id, pw.week_number, pw.year, pw.total_qty]
          );
        }
        updated++;
      }
    }

    await ppicLog(req, 'PUSH_TO_MPS', 'FORECAST', req.params.id, null, { mps_number: mps.mps_number, products_matched: productIds.length, weeks_updated: updated });
    res.json({
      message: `Forecast pushed to MPS ${mps.mps_number}`,
      mps_id: mps.id,
      mps_number: mps.mps_number,
      products_matched: productIds.length,
      products_created: created,
      weeks_updated: updated
    });
  } catch (error) {
    console.error('Error pushing forecast to MPS:', error);
    res.status(500).json({ error: 'Failed to push forecast to MPS' });
  }
});


// ============================================================
// SALES FORECAST — MONTHLY (YEARLY VIEW)
// ============================================================

// Helper: get weeks that overlap with a given month (reuses getWeekNumber from above)
const getWeeksForMonth = (year: number, month: number): { week: number; year: number }[] => {
  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);
  const seen = new Set<string>();
  const weeks: { week: number; year: number }[] = [];
  for (let d = new Date(firstDay); d <= lastDay; d.setDate(d.getDate() + 1)) {
    const wk = getWeekNumber(d);
    const yr = d.getFullYear();
    const key = `${yr}-W${wk}`;
    if (!seen.has(key)) {
      seen.add(key);
      weeks.push({ week: wk, year: yr });
    }
  }
  return weeks;
};

// GET /forecast-monthly?year=2026
router.get('/forecast-monthly', authMiddleware, async (req: Request, res: Response) => {
  try {
    const year = Number(req.query.year) || new Date().getFullYear();
    const brands = await dbAll(
      `SELECT fb.*, p.name AS product_name, p.sku AS product_sku
       FROM forecast_brands fb
       LEFT JOIN products p ON fb.product_id = p.id
       WHERE fb.is_active = 1 ORDER BY fb.brand_name ASC`
    ) as any[];

    const monthlyData = await dbAll(
      'SELECT * FROM forecast_monthly_data WHERE year = ?', [year]
    ) as any[];

    const dataMap: Record<number, Record<number, any>> = {};
    for (const row of monthlyData) {
      if (!dataMap[row.brand_id]) dataMap[row.brand_id] = {};
      dataMap[row.brand_id][row.month] = {
        forecast_qty: Number(row.forecast_qty),
        product_qty: Number(row.product_qty)
      };
    }

    const grid = brands.map((b: any) => {
      const months: any[] = [];
      for (let m = 1; m <= 12; m++) {
        const d = dataMap[b.id]?.[m];
        months.push({
          month: m,
          forecast_qty: d?.forecast_qty || 0,
          product_qty: d?.product_qty || 0
        });
      }
      return { ...b, months };
    });

    res.json({ success: true, data: { year, brands: grid } });
  } catch (error) {
    console.error('Error fetching monthly forecast:', error);
    res.status(500).json({ error: 'Failed to fetch monthly forecast' });
  }
});

// PUT /forecast-monthly — save monthly data (batch)
router.put('/forecast-monthly', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { year, data } = req.body;
    if (!year || !Array.isArray(data)) return res.status(400).json({ error: 'year and data[] required' });

    let updated = 0;
    for (const entry of data) {
      const { brand_id, month, forecast_qty } = entry;
      if (!brand_id || !month) continue;
      const brand = await dbGet('SELECT conversion_rate FROM forecast_brands WHERE id = ?', [brand_id]) as any;
      const rate = Number(brand?.conversion_rate || 1);
      const productQty = Math.round(Number(forecast_qty || 0) * rate * 100) / 100;

      await dbRun(
        `INSERT INTO forecast_monthly_data (year, brand_id, month, forecast_qty, product_qty)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE forecast_qty = VALUES(forecast_qty), product_qty = VALUES(product_qty)`,
        [year, brand_id, month, Number(forecast_qty || 0), productQty]
      );
      updated++;
    }

    await ppicLog(req, 'UPDATE', 'FORECAST_MONTHLY', year, null, { year, entries: updated });
    res.json({ success: true, message: `${updated} entries saved`, year });
  } catch (error) {
    console.error('Error saving monthly forecast:', error);
    res.status(500).json({ error: 'Failed to save monthly forecast' });
  }
});

// POST /forecast-monthly/distribute — distribute monthly to weekly
router.post('/forecast-monthly/distribute', authMiddleware, async (req: Request, res: Response) => {
  try {
    const year = Number(req.query.year || req.body.year) || new Date().getFullYear();
    const targetMonth = Number(req.query.month || req.body.month) || 0;

    let monthlyData: any[];
    if (targetMonth > 0) {
      monthlyData = await dbAll(
        'SELECT * FROM forecast_monthly_data WHERE year = ? AND month = ? AND forecast_qty > 0',
        [year, targetMonth]
      ) as any[];
    } else {
      monthlyData = await dbAll(
        'SELECT * FROM forecast_monthly_data WHERE year = ? AND forecast_qty > 0', [year]
      ) as any[];
    }

    if (monthlyData.length === 0) {
      return res.json({ success: true, message: 'No monthly data to distribute', distributed: 0 });
    }

    const byMonth: Record<number, any[]> = {};
    for (const row of monthlyData) {
      if (!byMonth[row.month]) byMonth[row.month] = [];
      byMonth[row.month].push(row);
    }

    let totalDistributed = 0;
    const userId = (req as any).user?.userId || null;

    for (const [monthStr, entries] of Object.entries(byMonth)) {
      const month = Number(monthStr);
      let header = await dbGet(
        'SELECT id, status FROM forecast_headers WHERE period_year = ? AND period_month = ?',
        [year, month]
      ) as any;

      if (!header) {
        const fcNum = `FC-${year}-${String(month).padStart(2, '0')}`;
        const result = await dbRun(
          'INSERT INTO forecast_headers (forecast_number, period_year, period_month, notes, created_by) VALUES (?, ?, ?, ?, ?)',
          [fcNum, year, month, 'Auto-created from monthly forecast', userId]
        ) as any;
        header = { id: result.insertId, status: 'Draft' };
      }

      const weeks = getWeeksForMonth(year, month);
      if (weeks.length === 0) continue;

      for (const entry of entries) {
        const brand = await dbGet('SELECT conversion_rate FROM forecast_brands WHERE id = ?', [entry.brand_id]) as any;
        const rate = Number(brand?.conversion_rate || 1);
        const weeklyQty = Math.round(Number(entry.forecast_qty) / weeks.length * 100) / 100;
        const weeklyProductQty = Math.round(weeklyQty * rate * 100) / 100;

        for (const w of weeks) {
          await dbRun(
            `INSERT INTO forecast_week_data (forecast_header_id, brand_id, week_number, year, forecast_qty, product_qty)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE forecast_qty = VALUES(forecast_qty), product_qty = VALUES(product_qty)`,
            [header.id, entry.brand_id, w.week, w.year, weeklyQty, weeklyProductQty]
          );
        }
        totalDistributed++;
      }
    }

    await ppicLog(req, 'DISTRIBUTE', 'FORECAST_MONTHLY', year, null, { year, month: targetMonth, distributed: totalDistributed });
    res.json({
      success: true,
      message: `Distributed ${totalDistributed} brand(s) across ${targetMonth > 0 ? '1 month' : Object.keys(byMonth).length + ' months'}`,
      distributed: totalDistributed
    });
  } catch (error) {
    console.error('Error distributing monthly forecast:', error);
    res.status(500).json({ error: 'Failed to distribute monthly forecast' });
  }
});

// POST /forecast-monthly/push-to-mps — Push monthly forecast data directly to MPS
router.post('/forecast-monthly/push-to-mps', authMiddleware, async (req: Request, res: Response) => {
  try {
    const year = Number(req.query.year || req.body.year) || new Date().getFullYear();

    // Get all monthly data with product info
    const monthlyData = await dbAll(`
      SELECT fmd.*, fb.product_id, fb.conversion_rate, fb.brand_name
      FROM forecast_monthly_data fmd
      JOIN forecast_brands fb ON fmd.brand_id = fb.id
      WHERE fmd.year = ? AND fmd.forecast_qty > 0 AND fb.product_id IS NOT NULL
    `, [year]) as any[];

    if (monthlyData.length === 0) {
      return res.status(400).json({ error: 'No monthly forecast data with linked products to push' });
    }

    // Aggregate by product_id + week (across all brands that map to same product)
    // Step 1: build product_id → month → total_product_qty
    const productMonthQty: Record<number, Record<number, number>> = {};
    for (const row of monthlyData) {
      const pid = row.product_id;
      const month = row.month;
      const rate = Number(row.conversion_rate) || 1;
      const pqty = Math.round(Number(row.forecast_qty) * rate * 100) / 100;
      if (!productMonthQty[pid]) productMonthQty[pid] = {};
      productMonthQty[pid][month] = (productMonthQty[pid][month] || 0) + pqty;
    }

    // Step 2: expand to product_id → week → qty
    const productWeekQty: Record<number, { week: number; year: number; qty: number }[]> = {};
    for (const [pidStr, monthMap] of Object.entries(productMonthQty)) {
      const pid = Number(pidStr);
      productWeekQty[pid] = [];
      for (const [mStr, totalQty] of Object.entries(monthMap)) {
        const month = Number(mStr);
        const weeks = getWeeksForMonth(year, month);
        const weeklyQty = Math.round(totalQty / weeks.length * 100) / 100;
        for (const w of weeks) {
          // Check if week already exists (from another month overlap)
          const existing = productWeekQty[pid].find(x => x.week === w.week && x.year === w.year);
          if (existing) {
            existing.qty += weeklyQty;
          } else {
            productWeekQty[pid].push({ week: w.week, year: w.year, qty: weeklyQty });
          }
        }
      }
    }

    // Step 3: Find or create MPS for year, push data
    // Look for Draft MPS — prefer one matching the year
    let mps = await dbGet(
      `SELECT * FROM mps_headers WHERE period_year = ? AND status = 'Draft' ORDER BY id DESC LIMIT 1`,
      [year]
    ) as any;
    if (!mps) {
      mps = await dbGet(
        `SELECT * FROM mps_headers WHERE status = 'Draft' ORDER BY id DESC LIMIT 1`
      ) as any;
    }
    if (!mps) return res.status(400).json({ error: 'No Draft MPS found. Create an MPS first.' });

    let productsMatched = 0;
    let productsCreated = 0;
    let weeksUpdated = 0;

    for (const [pidStr, weekEntries] of Object.entries(productWeekQty)) {
      const productId = Number(pidStr);

      // Find or create MPS detail
      let mpsDetail = await dbGet(
        'SELECT id FROM mps_details WHERE mps_header_id = ? AND product_id = ?',
        [mps.id, productId]
      ) as any;

      if (!mpsDetail) {
        const product = await dbGet('SELECT id, name FROM products WHERE id = ?', [productId]) as any;
        if (!product) continue;
        const bom = await dbGet(
          "SELECT id FROM bom_headers WHERE product_id = ? AND status = 'ACTIVE' LIMIT 1",
          [productId]
        ) as any;
        const result = await dbRun(
          "INSERT INTO mps_details (mps_header_id, product_id, bom_id, demand_qty, status, lead_time_weeks) VALUES (?, ?, ?, 0, 'Pending', 1)",
          [mps.id, productId, bom?.id || null]
        );
        mpsDetail = { id: result.insertId };
        productsCreated++;
      }
      productsMatched++;

      // Update MPS week data
      for (const we of weekEntries) {
        const existingWeek = await dbGet(
          'SELECT id FROM mps_week_data WHERE mps_detail_id = ? AND year = ? AND week_number = ?',
          [mpsDetail.id, we.year, we.week]
        ) as any;

        if (existingWeek) {
          await dbRun(
            'UPDATE mps_week_data SET forecast_qty = ? WHERE id = ?',
            [we.qty, existingWeek.id]
          );
        } else {
          await dbRun(
            'INSERT INTO mps_week_data (mps_detail_id, week_number, year, forecast_qty, so_qty, start_process_qty, fg_qty, production_qty) VALUES (?, ?, ?, ?, 0, 0, 0, 0)',
            [mpsDetail.id, we.week, we.year, we.qty]
          );
        }
        weeksUpdated++;
      }
    }

    await ppicLog(req, 'PUSH_TO_MPS', 'FORECAST_MONTHLY', year, null, {
      mps_number: mps.mps_number, products: productsMatched, weeks: weeksUpdated
    });

    res.json({
      success: true,
      message: `Monthly forecast ${year} pushed to MPS ${mps.mps_number}`,
      mps_id: mps.id,
      mps_number: mps.mps_number,
      products_matched: productsMatched,
      products_created: productsCreated,
      weeks_updated: weeksUpdated
    });
  } catch (error) {
    console.error('Error pushing monthly forecast to MPS:', error);
    res.status(500).json({ error: 'Failed to push monthly forecast to MPS' });
  }
});

// ===========================================================================
// AGGREGATED MRP — Cross-MPS Material Requirement Planning
// ===========================================================================

// GET /api/ppic/mrp?year=2026
// Returns aggregated gross requirements from all active MPS × BOM, per material per week
router.get('/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const year = Number(req.query.year) || new Date().getFullYear();

    // Step 1: Get all week columns for the year (from active MPS details)
    const weekCols = await dbAll(
      `SELECT DISTINCT md.week_number, mh.period_year AS year
       FROM mps_details md
       JOIN mps_headers mh ON md.mps_header_id = mh.id
       WHERE mh.period_year = ? AND mh.status IN ('draft','approved','active','Draft','Approved','Active')
         AND md.rec_production > 0
       ORDER BY md.week_number ASC`,
      [year]
    ) as any[];

    if (!weekCols.length) {
      return res.json({ data: { materials: [], weekColumns: [] } });
    }

    // Step 2: Explode BOM × MPS quantities to get gross requirements per material per week
    const grossRows = await dbAll(
      `SELECT md.week_number,
              mh.period_year AS year,
              bd.raw_material_id AS material_id,
              rm.name AS material_name,
              rm.sku AS material_sku,
              rm.unit_of_measure_id,
              u.name AS uom_name,
              pt.code AS product_type_code,
              SUM(bd.quantity * md.rec_production) AS gross_requirements
       FROM mps_details md
       JOIN mps_headers mh ON md.mps_header_id = mh.id
       JOIN products p ON md.product_id = p.id
       JOIN bom_headers bh ON bh.product_id = p.id AND bh.status IN ('approved','ACTIVE','active','Active')
       JOIN bom_details bd ON bd.bom_header_id = bh.id
       JOIN products rm ON rm.id = bd.raw_material_id
       LEFT JOIN uom u ON rm.unit_of_measure_id = u.id
       LEFT JOIN product_types pt ON rm.product_type_id = pt.id
       WHERE mh.period_year = ?
         AND mh.status IN ('draft','approved','active','Draft','Approved','Active')
         AND md.rec_production > 0
       GROUP BY md.week_number, mh.period_year, bd.raw_material_id, rm.name, rm.sku, rm.uom_id, u.name, pt.code
       ORDER BY rm.name ASC, md.week_number ASC`,
      [year]
    ) as any[];

    // Step 3: Get saved planned orders
    const savedOrders = await dbAll(
      `SELECT material_id, week_number, year, planned_order_release, planned_order_receipt
       FROM mrp_planned_orders WHERE year = ?`,
      [year]
    ) as any[];

    // Step 4: Get material settings (lead_time, first_stock, order_quantity)
    const settings = await dbAll(
      `SELECT material_id, lead_time, first_stock, order_quantity FROM mrp_material_settings`
    ) as any[];
    const settingsMap: Record<number, any> = {};
    for (const s of settings) settingsMap[s.material_id] = s;

    // Step 5: Aggregate by material
    const materialMap: Record<number, any> = {};
    for (const row of grossRows) {
      const mid = row.material_id;
      if (!materialMap[mid]) {
        const sett = settingsMap[mid] || {};
        materialMap[mid] = {
          material_id: mid,
          material_name: row.material_name,
          material_sku: row.material_sku,
          uom_name: row.uom_name,
          product_type_code: row.product_type_code,
          lead_time: sett.lead_time || 2,
          first_stock: Number(sett.first_stock) || 0,
          order_quantity: Number(sett.order_quantity) || 0,
          weeks: weekCols.map((wc: any) => ({
            week_number: wc.week,
            year: wc.year,
            gross_requirements: 0,
            planned_order_release: 0,
            planned_order_receipt: 0
          }))
        };
      }
      // Fill gross requirements for this week
      const wIdx = weekCols.findIndex((wc: any) => wc.week === row.week_number && wc.year === row.year);
      if (wIdx >= 0) {
        materialMap[mid].weeks[wIdx].gross_requirements = Number(row.gross_requirements);
      }
    }

    // Step 6: Fill in saved planned orders
    for (const po of savedOrders) {
      if (materialMap[po.material_id]) {
        const wIdx = weekCols.findIndex((wc: any) => wc.week === po.week_number && wc.year === po.year);
        if (wIdx >= 0) {
          materialMap[po.material_id].weeks[wIdx].planned_order_release = Number(po.planned_order_release) || 0;
          materialMap[po.material_id].weeks[wIdx].planned_order_receipt = Number(po.planned_order_receipt) || 0;
        }
      }
    }

    // Step 7: Build week column labels with date ranges
    const weekColumns = weekCols.map((wc: any) => {
      // Calculate date range for the week
      const jan1 = new Date(wc.year, 0, 1);
      const dayOfWeek = jan1.getDay();
      const startDay = (wc.week - 1) * 7 - dayOfWeek + 1;
      const start = new Date(wc.year, 0, startDay + 1);
      const end = new Date(wc.year, 0, startDay + 7);
      const fmt = (d: Date) => `${d.getDate()}/${d.getMonth() + 1}`;
      return {
        week: wc.week,
        year: wc.year,
        label: `W${wc.week}`,
        dateRange: `${fmt(start)}-${fmt(end)}`
      };
    });

    res.json({ data: { materials: Object.values(materialMap), weekColumns } });
  } catch (error) {
    console.error('Error fetching aggregated MRP:', error);
    res.status(500).json({ error: 'Failed to fetch MRP data' });
  }
});

// PUT /api/ppic/mrp — Save planned orders + material settings
router.put('/mrp', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { entries, materialSettings, year } = req.body as any;
    let updated = 0;

    // Save planned orders (release & receipt per material per week)
    if (Array.isArray(entries)) {
      for (const e of entries) {
        const existing = await dbGet(
          `SELECT id FROM mrp_planned_orders WHERE material_id=? AND week_number=? AND year=?`,
          [e.material_id, e.week_number, e.year || year]
        ) as any;
        if (existing) {
          await dbRun(
            `UPDATE mrp_planned_orders SET planned_order_release=?, planned_order_receipt=? WHERE id=?`,
            [e.planned_order_release || 0, e.planned_order_receipt || 0, existing.id]
          );
        } else {
          await dbRun(
            `INSERT INTO mrp_planned_orders (material_id, week_number, year, planned_order_release, planned_order_receipt) VALUES (?,?,?,?,?)`,
            [e.material_id, e.week_number, e.year || year, e.planned_order_release || 0, e.planned_order_receipt || 0]
          );
        }
        updated++;
      }
    }

    // Save material settings (lead_time, first_stock, order_quantity)
    if (Array.isArray(materialSettings)) {
      for (const s of materialSettings) {
        const existing = await dbGet(
          `SELECT id FROM mrp_material_settings WHERE material_id=?`, [s.material_id]
        ) as any;
        if (existing) {
          await dbRun(
            `UPDATE mrp_material_settings SET lead_time=?, first_stock=?, order_quantity=? WHERE id=?`,
            [s.lead_time || 2, s.first_stock || 0, s.order_quantity || 0, existing.id]
          );
        } else {
          await dbRun(
            `INSERT INTO mrp_material_settings (material_id, lead_time, first_stock, order_quantity) VALUES (?,?,?,?)`,
            [s.material_id, s.lead_time || 2, s.first_stock || 0, s.order_quantity || 0]
          );
        }
      }
    }

    res.json({ message: 'MRP data saved', updated });
  } catch (error) {
    console.error('Error saving MRP:', error);
    res.status(500).json({ error: 'Failed to save MRP data' });
  }
});

// POST /api/ppic/mrp/generate-pr — Create Purchase Request from materials with net requirements
router.post('/mrp/generate-pr', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { materials, year, notes } = req.body as any;
    const userId = (req as any).user?.userId;

    if (!materials || !materials.length) {
      return res.status(400).json({ error: 'No materials selected' });
    }

    // Create PR header
    const now = new Date();
    const prNumber = `PR-MRP-${year}-${String(now.getMonth() + 1).padStart(2,'0')}${String(now.getDate()).padStart(2,'0')}-${Date.now().toString().slice(-4)}`;

    const result = await dbRun(
      `INSERT INTO purchase_requests (pr_number, request_date, status, notes, created_by, department)
       VALUES (?, CURDATE(), 'pending', ?, ?, 'PPIC')`,
      [prNumber, notes || `Auto-generated from MRP aggregation ${year}`, userId]
    ) as any;

    const prId = result.lastID || result.insertId;

    // Insert PR items
    let itemsCreated = 0;
    for (const mat of materials) {
      await dbRun(
        `INSERT INTO purchase_request_items (pr_id, product_id, quantity, unit_price, notes)
         VALUES (?, ?, ?, 0, ?)`,
        [prId, mat.material_id, mat.total_net_requirement,
         `MRP net requirement – lead time ${mat.lead_time} week(s)`]
      );
      itemsCreated++;
    }

    await ppicLog(req, 'CREATE', 'purchase_request', prId, null, { prNumber, from: 'MRP', year });

    res.json({
      success: true,
      message: `PR ${prNumber} berhasil dibuat dengan ${itemsCreated} item`,
      pr_id: prId,
      pr_number: prNumber
    });
  } catch (error) {
    console.error('Error generating PR from MRP:', error);
    res.status(500).json({ error: 'Failed to generate Purchase Request' });
  }
});

export default router;
