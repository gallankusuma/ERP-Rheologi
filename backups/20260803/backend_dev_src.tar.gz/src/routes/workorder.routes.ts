import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = Router();

const WO_SELECT = `
  SELECT w.*,
    p.name as product_name, p.sku as product_sku,
    lp.name as line_process_name, lp.code as line_process_code,
    lp.capacity_per_hour,
    u.name as capacity_unit_name,
    mh.mps_number, mh.period_month as mps_period_month, mh.period_year as mps_period_year,
    w.week_number as mps_week_number,
    ub.full_name as created_by_name
  FROM work_orders w
  JOIN products p ON w.product_id = p.id
  LEFT JOIN line_processes lp ON w.line_process_id = lp.id
  LEFT JOIN uom u ON lp.capacity_unit_id = u.id
  LEFT JOIN mps_details md ON w.mps_detail_id = md.id
  LEFT JOIN mps_headers mh ON md.mps_header_id = mh.id
  LEFT JOIN users ub ON w.created_by = ub.id
`;

// GET /api/workorders — list with optional filters
router.get('/', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { status, search, month, year } = req.query as any;
    const conditions: string[] = [];
    const params: any[] = [];

    if (status && status !== 'all') {
      conditions.push('w.status = ?');
      params.push(status);
    }
    if (search) {
      conditions.push('(w.wo_number LIKE ? OR p.name LIKE ? OR p.sku LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (month && year) {
      conditions.push('MONTH(w.scheduled_start) = ? AND YEAR(w.scheduled_start) = ?');
      params.push(Number(month), Number(year));
    }

    const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';
    const workOrders = await dbAll(
      `${WO_SELECT} ${where} ORDER BY w.scheduled_start ASC, w.created_at DESC`,
      params
    );
    res.json({ data: workOrders });
  } catch (error) {
    console.error('Error fetching work orders:', error);
    res.status(500).json({ error: 'Failed to fetch work orders' });
  }
});

// GET /api/workorders/summary — status counts (MUST be before /:id)
router.get('/summary', authMiddleware, async (_req: Request, res: Response) => {
  try {
    const rows = await dbAll(
      `SELECT status, COUNT(*) as count, SUM(quantity) as total_qty, SUM(completed_quantity) as total_done
       FROM work_orders GROUP BY status`
    ) as any[];
    res.json({ data: rows });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch summary' });
  }
});

// GET /api/workorders/:id
router.get('/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const workOrder = await dbGet(
      `${WO_SELECT} WHERE w.id = ?`,
      [req.params.id]
    );
    if (!workOrder) return res.status(404).json({ error: 'Work order not found' });
    res.json({ data: workOrder });
  } catch (error) {
    console.error('Error fetching work order:', error);
    res.status(500).json({ error: 'Failed to fetch work order' });
  }
});

// POST /api/workorders
router.post('/', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { product_id, bom_id, quantity, status, priority, scheduled_start, scheduled_end, line_process_id, notes } = req.body;

    if (!product_id || !quantity) {
      return res.status(400).json({ error: 'product_id and quantity are required' });
    }

    // Auto-generate wo_number: WO-YYYYMMDD-NNN
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const existing = await dbGet(
      `SELECT COUNT(*) as cnt FROM work_orders WHERE wo_number LIKE ?`,
      [`WO-${dateStr}-%`]
    ) as any;
    const seq = String((existing?.cnt || 0) + 1).padStart(3, '0');
    const woNumber = `WO-${dateStr}-${seq}`;
    const userId = (req as any).user?.id || null;

    const result = await dbRun(
      `INSERT INTO work_orders(wo_number, product_id, bom_id, quantity, status, priority, scheduled_start, scheduled_end, line_process_id, notes, created_by)
       VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        woNumber, product_id, bom_id || null, quantity,
        status || 'DRAFT', priority || 'normal',
        scheduled_start || null, scheduled_end || null,
        line_process_id || null, notes || null, userId
      ]
    );

    res.status(201).json({
      message: 'Work order created successfully',
      data: { id: result.insertId, wo_number: woNumber },
    });
  } catch (error) {
    console.error('Error creating work order:', error);
    res.status(500).json({ error: 'Failed to create work order' });
  }
});

// PUT /api/workorders/:id — update core fields
router.put('/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const {
      quantity, status, priority,
      scheduled_start, scheduled_end,
      actual_start, actual_end,
      line_process_id, notes, completed_quantity
    } = req.body;

    await dbRun(
      `UPDATE work_orders
       SET quantity = ?,
           status = ?,
           priority = ?,
           scheduled_start = ?,
           scheduled_end = ?,
           actual_start = ?,
           actual_end = ?,
           line_process_id = ?,
           notes = ?,
           completed_quantity = ?,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [
        quantity,
        status,
        priority || 'normal',
        scheduled_start || null,
        scheduled_end || null,
        actual_start || null,
        actual_end || null,
        line_process_id || null,
        notes || null,
        completed_quantity || 0,
        req.params.id
      ]
    );

    res.json({ message: 'Work order updated successfully' });
  } catch (error) {
    console.error('Error updating work order:', error);
    res.status(500).json({ error: 'Failed to update work order' });
  }
});

// PATCH /api/workorders/:id/status — quick status change
router.patch('/:id/status', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { status, actual_start, actual_end, completed_quantity } = req.body;
    if (!status) return res.status(400).json({ error: 'status is required' });

    await dbRun(
      `UPDATE work_orders
       SET status = ?,
           actual_start = COALESCE(?, actual_start),
           actual_end = COALESCE(?, actual_end),
           completed_quantity = COALESCE(?, completed_quantity),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [status, actual_start || null, actual_end || null, completed_quantity ?? null, req.params.id]
    );

    res.json({ message: `WO status updated to ${status}` });
  } catch (error) {
    console.error('Error updating WO status:', error);
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// DELETE /api/workorders/:id — only DRAFT allowed
router.delete('/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const wo = await dbGet('SELECT id, status, wo_number FROM work_orders WHERE id = ?', [req.params.id]) as any;
    if (!wo) return res.status(404).json({ error: 'Work order not found' });
    if (wo.status !== 'DRAFT') {
      return res.status(400).json({ error: `Cannot delete WO with status "${wo.status}". Only DRAFT WOs can be deleted.` });
    }

    await dbRun('DELETE FROM work_orders WHERE id = ?', [req.params.id]);
    res.json({ message: `Work order ${wo.wo_number} deleted` });
  } catch (error) {
    console.error('Error deleting work order:', error);
    res.status(500).json({ error: 'Failed to delete work order' });
  }
});

export default router;
