import express, { Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = express.Router();

// ===== POSITION RATES (MASTER STANDAR GAJI) =====

router.get('/position-rates', authMiddleware, async (req: Request, res: Response) => {
  try {
    const rows = await dbAll(
      'SELECT * FROM position_rates WHERE is_active = 1 ORDER BY position_name ASC, grade ASC', []
    );
    res.json({ data: rows });
  } catch (error) {
    console.error('Error fetching position rates:', error);
    res.status(500).json({ error: 'Failed to fetch position rates' });
  }
});

router.get('/position-rates/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const row = await dbGet('SELECT * FROM position_rates WHERE id = ?', [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Position rate not found' });
    res.json({ data: row });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch position rate' });
  }
});

router.post('/position-rates', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { position_code, position_name, grade, salary_type, basic_rate, tunjangan_rate, ot_rate, description } = req.body;
    if (!position_code || !position_name) return res.status(400).json({ error: 'position_code and position_name required' });
    const result = await dbRun(
      `INSERT INTO position_rates (position_code, position_name, grade, salary_type, basic_rate, tunjangan_rate, ot_rate, description)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [position_code, position_name, grade || null, salary_type || 'daily',
       Number(basic_rate || 0), Number(tunjangan_rate || 0), Number(ot_rate || 0), description || null]
    );
    res.status(201).json({ message: 'Position rate created', data: { id: result.insertId } });
  } catch (error: any) {
    if (error.message?.includes('Duplicate')) return res.status(400).json({ error: 'Position code must be unique' });
    res.status(500).json({ error: 'Failed to create position rate' });
  }
});

router.put('/position-rates/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { position_code, position_name, grade, salary_type, basic_rate, tunjangan_rate, ot_rate, description, is_active } = req.body;
    await dbRun(
      `UPDATE position_rates SET position_code=?, position_name=?, grade=?, salary_type=?, basic_rate=?, tunjangan_rate=?, ot_rate=?, description=?, is_active=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`,
      [position_code, position_name, grade || null, salary_type || 'daily',
       Number(basic_rate || 0), Number(tunjangan_rate || 0), Number(ot_rate || 0),
       description || null, is_active !== undefined ? (is_active ? 1 : 0) : 1, req.params.id]
    );
    res.json({ message: 'Position rate updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update position rate' });
  }
});

router.delete('/position-rates/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM position_rates WHERE id = ?', [req.params.id]);
    res.json({ message: 'Position rate deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete position rate' });
  }
});

// ===== EMPLOYEES (HR LITE) =====

router.get('/employees', authMiddleware, async (req: Request, res: Response) => {
  try {
    const employees = await dbAll(
      `SELECT e.id, e.code as employee_code, e.name as first_name, '' as last_name,
              e.email, e.phone, e.position, e.department_id, e.hire_date,
              e.salary as basic_salary, e.salary_type as contract_type,
              e.basic_rate, e.tunjangan_rate, e.ot_rate, e.status,
              e.created_at, e.updated_at, d.name as department_name
       FROM employees e
       LEFT JOIN departments d ON e.department_id = d.id
       ORDER BY e.code ASC`,
      []
    );
    res.json({ data: employees });
  } catch (error) {
    console.error('Error fetching employees:', error);
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
});

router.get('/employees/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const employee = await dbGet(
      `SELECT e.*, d.name as department_name FROM employees e
       LEFT JOIN departments d ON e.department_id = d.id WHERE e.id = ?`,
      [req.params.id]
    );
    if (!employee) return res.status(404).json({ error: 'Employee not found' });
    res.json({ data: employee });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
});

router.post('/employees', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { code, employee_code, name, first_name, last_name, email, phone, department_id, position, hire_date, is_active,
            basic_rate, tunjangan_rate, ot_rate, salary_type, contract_type, basic_salary, salary } = req.body;
    const empCode = code || employee_code;
    const empName = name || [first_name, last_name].filter(Boolean).join(' ');
    const empSalaryType = salary_type || contract_type || 'daily';
    const empSalary = salary || basic_salary || 0;
    if (!empCode || !empName) return res.status(400).json({ error: 'code and name are required' });
    const result = await dbRun(
      `INSERT INTO employees (code, name, email, phone, department_id, position, hire_date, status, basic_rate, tunjangan_rate, ot_rate, salary_type, salary)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [empCode, empName, email||null, phone||null, department_id||null, position||null, hire_date||null,
       is_active !== undefined ? (is_active ? 'ACTIVE' : 'INACTIVE') : 'ACTIVE',
       basic_rate||0, tunjangan_rate||0, ot_rate||0, empSalaryType, empSalary]
    );
    res.status(201).json({ message: 'Employee created', data: { id: result.insertId, code: empCode, name: empName } });
  } catch (error: any) {
    if (error.message?.includes('Duplicate entry')) return res.status(400).json({ error: 'Employee code must be unique' });
    res.status(500).json({ error: 'Failed to create employee' });
  }
});

router.put('/employees/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, first_name, last_name, email, phone, department_id, position, hire_date, is_active,
            basic_rate, tunjangan_rate, ot_rate, salary_type, contract_type, basic_salary, salary } = req.body;
    const empName = name || [first_name, last_name].filter(Boolean).join(' ');
    const empSalaryType = salary_type || contract_type || 'daily';
    const empSalary = salary || basic_salary || 0;
    await dbRun(
      `UPDATE employees 
       SET name=?, email=?, phone=?, department_id=?, position=?, hire_date=?, status=?,
           basic_rate=?, tunjangan_rate=?, ot_rate=?, salary_type=?,
           salary=?, updated_at=CURRENT_TIMESTAMP
       WHERE id=?`,
      [empName, email||null, phone||null, department_id||null, position||null, hire_date||null,
       is_active !== undefined ? (is_active ? 'ACTIVE' : 'INACTIVE') : 'ACTIVE',
       basic_rate||0, tunjangan_rate||0, ot_rate||0, empSalaryType,
       empSalary, req.params.id]
    );
    res.json({ message: 'Employee updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update employee' });
  }
});

router.delete('/employees/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM employees WHERE id = ?', [req.params.id]);
    res.json({ message: 'Employee deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete employee' });
  }
});

// ===== ATTENDANCE =====

router.get('/attendance', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { project_id, month, year, employee_id } = req.query;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (project_id) { where += ' AND a.project_id = ?'; params.push(project_id); }
    if (employee_id) { where += ' AND a.employee_id = ?'; params.push(employee_id); }
    if (month && year) { where += ' AND MONTH(a.date) = ? AND YEAR(a.date) = ?'; params.push(month, year); }
    const rows = await dbAll(
      `SELECT a.*, e.name as employee_name, e.code as employee_code, e.position,
              e.salary, e.basic_rate, e.tunjangan_rate, p.project_name as project_name
       FROM attendance_logs a
       LEFT JOIN employees e ON a.employee_id = e.id
       LEFT JOIN client_projects p ON a.project_id = p.id
       ${where} ORDER BY a.date DESC, e.name ASC`,
      params
    );
    res.json({ data: rows });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch attendance' }); }
});

router.post('/attendance', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, date, project_id, check_in, check_out, status, timesheet_value, overtime_hours, notes } = req.body;
    if (!employee_id || !date) return res.status(400).json({ error: 'employee_id and date are required' });
    const existing: any = await dbGet('SELECT id FROM attendance_logs WHERE employee_id = ? AND date = ?', [employee_id, date]);
    if (existing) {
      await dbRun(
        'UPDATE attendance_logs SET check_in=?, check_out=?, status=?, timesheet_value=?, overtime_hours=?, notes=?, project_id=? WHERE id=?',
        [check_in||null, check_out||null, status||'present', timesheet_value??1, overtime_hours??0, notes||null, project_id||null, existing.id]
      );
      res.json({ message: 'Attendance updated', data: { id: existing.id } });
    } else {
      const result = await dbRun(
        'INSERT INTO attendance_logs (employee_id, date, project_id, check_in, check_out, status, timesheet_value, overtime_hours, notes) VALUES (?,?,?,?,?,?,?,?,?)',
        [employee_id, date, project_id||null, check_in||null, check_out||null, status||'present', timesheet_value??1, overtime_hours??0, notes||null]
      );
      res.status(201).json({ message: 'Attendance recorded', data: { id: result.insertId } });
    }
  } catch (error) { res.status(500).json({ error: 'Failed to record attendance' }); }
});

router.post('/attendance/bulk', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { date, project_id, records } = req.body;
    if (!date || !records?.length) return res.status(400).json({ error: 'date and records required' });
    for (const r of records) {
      const ex: any = await dbGet('SELECT id FROM attendance_logs WHERE employee_id=? AND date=?', [r.employee_id, date]);
      if (ex) {
        await dbRun('UPDATE attendance_logs SET status=?, timesheet_value=?, check_in=?, check_out=?, overtime_hours=?, project_id=?, notes=? WHERE id=?',
          [r.status||'present', r.timesheet_value??1, r.check_in||null, r.check_out||null, r.overtime_hours??0, project_id||null, r.notes||null, ex.id]);
      } else {
        await dbRun('INSERT INTO attendance_logs (employee_id,date,project_id,status,timesheet_value,check_in,check_out,overtime_hours,notes) VALUES (?,?,?,?,?,?,?,?,?)',
          [r.employee_id, date, project_id||null, r.status||'present', r.timesheet_value??1, r.check_in||null, r.check_out||null, r.overtime_hours??0, r.notes||null]);
      }
    }
    res.json({ message: `${records.length} records saved` });
  } catch (error) { res.status(500).json({ error: 'Failed bulk attendance' }); }
});

// ===== SALARY ADVANCES (KASBON) =====

router.get('/advances', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, status } = req.query;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (employee_id) { where += ' AND sa.employee_id=?'; params.push(employee_id); }
    if (status) { where += ' AND sa.status=?'; params.push(status); }
    const rows = await dbAll(
      `SELECT sa.*, e.name as employee_name, e.code as employee_code, e.position
       FROM salary_advances sa JOIN employees e ON sa.employee_id=e.id
       ${where} ORDER BY sa.advance_date DESC, sa.created_at DESC`,
      params
    );
    res.json({ data: rows });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch advances' }); }
});

router.post('/advances', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, amount, description, advance_date, period_month, period_year } = req.body;
    if (!employee_id || !amount) return res.status(400).json({ error: 'employee_id and amount required' });
    const result = await dbRun(
      'INSERT INTO salary_advances (employee_id, amount, remaining, description, advance_date, period_month, period_year, status) VALUES (?,?,?,?,?,?,?,?)',
      [employee_id, amount, amount, description||null, advance_date||null, period_month||null, period_year||null, 'pending']
    );
    res.status(201).json({ message: 'Advance recorded', data: { id: result.insertId } });
  } catch (error) { res.status(500).json({ error: 'Failed to record advance' }); }
});

router.put('/advances/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { amount, remaining, description, advance_date, period_month, period_year, status } = req.body;
    await dbRun(
      'UPDATE salary_advances SET amount=?, remaining=?, description=?, advance_date=?, period_month=?, period_year=?, status=?, updated_at=CURRENT_TIMESTAMP WHERE id=?',
      [amount, remaining??amount, description||null, advance_date||null, period_month||null, period_year||null, status||'pending', req.params.id]
    );
    res.json({ message: 'Advance updated' });
  } catch (error) { res.status(500).json({ error: 'Failed to update advance' }); }
});

router.delete('/advances/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM salary_advances WHERE id=?', [req.params.id]);
    res.json({ message: 'Advance deleted' });
  } catch (error) { res.status(500).json({ error: 'Failed to delete advance' }); }
});

// ===== PAYSLIP ENGINE =====

router.get('/payslip', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, month, year, project_id } = req.query;
    if (!employee_id || !month || !year) return res.status(400).json({ error: 'employee_id, month, year required' });

    const emp: any = await dbGet('SELECT * FROM employees WHERE id=?', [employee_id]);
    if (!emp) return res.status(404).json({ error: 'Employee not found' });

    // Attendance logs for period
    let where = 'WHERE a.employee_id=? AND MONTH(a.date)=? AND YEAR(a.date)=?';
    const params: any[] = [employee_id, month, year];
    if (project_id) { where += ' AND a.project_id=?'; params.push(project_id); }
    const logs: any[] = await dbAll(
      `SELECT a.*, p.project_name as project_name FROM attendance_logs a
       LEFT JOIN client_projects p ON a.project_id=p.id ${where} ORDER BY a.date ASC`, params
    );

    // Determine rates — prefer basic_rate field, fallback to salary/22
    const basicRatePerDay  = emp.basic_rate > 0 ? parseFloat(emp.basic_rate) : Math.round((emp.salary||0)/22);
    const tunjanganPerDay  = emp.tunjangan_rate > 0 ? parseFloat(emp.tunjangan_rate) : 0;
    const otRatePerHour    = emp.ot_rate > 0 ? parseFloat(emp.ot_rate) : Math.round(basicRatePerDay/8*1.5);

    // Aggregate timesheet
    const totalDays    = logs.reduce((s: number, r: any) => s + (parseFloat(r.timesheet_value)||0), 0);
    const totalOTHours = logs.reduce((s: number, r: any) => s + (parseFloat(r.overtime_hours)||0), 0);

    // Calculation
    const basicSalary = Math.round(totalDays * basicRatePerDay);
    const tunjangan   = Math.round(totalDays * tunjanganPerDay);
    const otPay       = Math.round(totalOTHours * otRatePerHour);
    const grossSalary = basicSalary + tunjangan + otPay;

    // Pending advances for this employee (deducted from this payslip)
    const pendingAdvances: any[] = await dbAll(
      `SELECT * FROM salary_advances WHERE employee_id=? AND status='pending'
       AND (period_month IS NULL OR (period_month=? AND period_year=?))
       ORDER BY advance_date ASC LIMIT 2`,
      [employee_id, month, year]
    );
    const advance1 = pendingAdvances[0] ? parseFloat(pendingAdvances[0].remaining) : 0;
    const advance2 = pendingAdvances[1] ? parseFloat(pendingAdvances[1].remaining) : 0;
    const totalAdvances = advance1 + advance2;

    // Statutory deductions (BPJS + PPh21 — only for monthly salary employees typically)
    const bpjs_kes = emp.salary_type === 'monthly' ? Math.round(grossSalary * 0.01) : 0;
    const bpjs_tk  = emp.salary_type === 'monthly' ? Math.round(grossSalary * 0.02) : 0;
    const pph21    = emp.salary_type === 'monthly' && grossSalary > 5000000 ? Math.round((grossSalary - 5000000) * 0.05) : 0;
    const totalDeductions = totalAdvances + bpjs_kes + bpjs_tk + pph21;
    const netSalary = grossSalary - totalDeductions;

    res.json({
      employee: {
        id: emp.id, code: emp.code, name: emp.name, position: emp.position,
        salary_type: emp.salary_type||'daily', basic_rate: basicRatePerDay,
        tunjangan_rate: tunjanganPerDay, ot_rate: otRatePerHour
      },
      period: { month, year, project_id: project_id||null },
      attendance: { total_days: totalDays, total_ot_hours: totalOTHours, logs },
      calculation: {
        basic_rate_per_day: basicRatePerDay, tunjangan_per_day: tunjanganPerDay,
        ot_rate_per_hour: otRatePerHour,
        basic_salary: basicSalary, tunjangan, ot_pay: otPay, gross_salary: grossSalary
      },
      advances: {
        advance_1: advance1, advance_2: advance2, total: totalAdvances,
        records: pendingAdvances.map((a:any) => ({ id:a.id, amount:a.amount, remaining:a.remaining, description:a.description, date:a.advance_date }))
      },
      deductions: { bpjs_kes, bpjs_tk, pph21, total_statutory: bpjs_kes+bpjs_tk+pph21, total: totalDeductions },
      net_salary: netSalary,
    });
  } catch (error) {
    console.error('Payslip error:', error);
    res.status(500).json({ error: 'Failed to generate payslip' });
  }
});

// Save finalized payslip & mark advances as deducted
router.post('/payslip/save', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, period_month, period_year, project_id, calculation, advances, deductions, net_salary, notes } = req.body;
    // Save payslip record
    const result = await dbRun(
      `INSERT INTO payslip_records (employee_id, period_month, period_year, project_id,
        total_days, total_ot_hours, basic_salary, tunjangan, ot_pay, gross_salary,
        advance_1, advance_2, reimbursement, bpjs_kes, bpjs_tk, pph21, total_deductions, net_salary, notes, status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'final')`,
      [employee_id, period_month, period_year, project_id||null,
       calculation.total_days||0, calculation.total_ot_hours||0,
       calculation.basic_salary||0, calculation.tunjangan||0, calculation.ot_pay||0, calculation.gross_salary||0,
       advances.advance_1||0, advances.advance_2||0, req.body.reimbursement||0,
       deductions.bpjs_kes||0, deductions.bpjs_tk||0, deductions.pph21||0, deductions.total||0,
       net_salary||0, notes||null]
    );
    // Mark advances as deducted
    if (advances.records?.length) {
      for (const adv of advances.records) {
        await dbRun("UPDATE salary_advances SET status='deducted', remaining=0, updated_at=CURRENT_TIMESTAMP WHERE id=?", [adv.id]);
      }
    }
    res.status(201).json({ message: 'Payslip saved', data: { id: result.insertId } });
  } catch (error) { res.status(500).json({ error: 'Failed to save payslip' }); }
});

// Get saved payslips history
router.get('/payslip/history', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { employee_id, year } = req.query;
    let where = 'WHERE 1=1';
    const params: any[] = [];
    if (employee_id) { where += ' AND pr.employee_id=?'; params.push(employee_id); }
    if (year) { where += ' AND pr.period_year=?'; params.push(year); }
    const rows = await dbAll(
      `SELECT pr.*, e.name as employee_name, e.code as employee_code, e.position
       FROM payslip_records pr JOIN employees e ON pr.employee_id=e.id
       ${where} ORDER BY pr.period_year DESC, pr.period_month DESC`,
      params
    );
    res.json({ data: rows });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch payslip history' }); }
});

// ===== MOBILE / PWA ENDPOINTS (No admin auth — employee self-service) =====

// POST /hr/mobile/login — Employee login by NIK/code + name verification
router.post('/mobile/login', async (req: Request, res: Response) => {
  try {
    const { nik, name } = req.body;
    if (!nik) return res.status(400).json({ error: 'NIK diperlukan' });
    const emp: any = await dbGet(
      `SELECT e.id, e.code, e.name, e.position, e.department_id, e.status,
              e.salary_type, e.basic_rate, e.tunjangan_rate, d.name as department
       FROM employees e
       LEFT JOIN departments d ON e.department_id = d.id
       WHERE e.code = ? AND e.status = 'ACTIVE'`,
      [nik.trim().toUpperCase()]
    );
    if (!emp) return res.status(404).json({ error: 'NIK tidak ditemukan atau karyawan tidak aktif' });
    // Optional name verification (case-insensitive, partial match)
    if (name && !emp.name.toLowerCase().includes(name.toLowerCase().trim())) {
      return res.status(401).json({ error: 'Nama tidak cocok dengan NIK' });
    }
    res.json({ success: true, employee: emp });
  } catch (error) { res.status(500).json({ error: 'Login gagal' }); }
});

// POST /hr/mobile/checkin — Self check-in from mobile
router.post('/mobile/checkin', async (req: Request, res: Response) => {
  try {
    const { employee_id, type, latitude, longitude, project_id } = req.body;
    if (!employee_id || !type) return res.status(400).json({ error: 'employee_id and type required' });
    const emp: any = await dbGet('SELECT id, name FROM employees WHERE id = ? AND status = ?', [employee_id, 'ACTIVE']);
    if (!emp) return res.status(404).json({ error: 'Karyawan tidak ditemukan' });
    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const timeStr = now.toTimeString().slice(0, 5);
    const existing: any = await dbGet('SELECT * FROM attendance_logs WHERE employee_id=? AND date=?', [employee_id, today]);
    const location = (latitude && longitude) ? `${latitude},${longitude}` : null;

    if (type === 'in') {
      if (existing) {
        await dbRun('UPDATE attendance_logs SET check_in=?, status=?, timesheet_value=1 WHERE id=?',
          [timeStr, 'present', existing.id]);
      } else {
        await dbRun(
          'INSERT INTO attendance_logs (employee_id,date,project_id,check_in,status,timesheet_value,notes) VALUES (?,?,?,?,?,?,?)',
          [employee_id, today, project_id||null, timeStr, 'present', 1, location ? `GPS: ${location}` : null]
        );
      }
      res.json({ success: true, message: `Check-in ${timeStr} berhasil ✅`, time: timeStr, date: today });
    } else if (type === 'out') {
      if (!existing) return res.status(400).json({ error: 'Belum check-in hari ini' });
      await dbRun('UPDATE attendance_logs SET check_out=? WHERE id=?', [timeStr, existing.id]);
      res.json({ success: true, message: `Check-out ${timeStr} berhasil 👋`, time: timeStr, date: today });
    } else {
      res.status(400).json({ error: 'type must be "in" or "out"' });
    }
  } catch (error) { res.status(500).json({ error: 'Check-in gagal' }); }
});

// GET /hr/mobile/attendance/:employee_id — Recent attendance for mobile view
router.get('/mobile/attendance/:employee_id', async (req: Request, res: Response) => {
  try {
    const { month, year } = req.query;
    const m = month || (new Date().getMonth() + 1);
    const y = year || new Date().getFullYear();
    const rows = await dbAll(
      `SELECT date, check_in, check_out, status, timesheet_value, overtime_hours, notes
       FROM attendance_logs WHERE employee_id=? AND MONTH(date)=? AND YEAR(date)=?
       ORDER BY date DESC LIMIT 31`,
      [req.params.employee_id, m, y]
    );
    const totalDays = rows.reduce((s: number, r: any) => s + (parseFloat(r.timesheet_value) || 0), 0);
    const today = new Date().toISOString().slice(0, 10);
    const todayLog: any = await dbGet('SELECT * FROM attendance_logs WHERE employee_id=? AND date=?', [req.params.employee_id, today]);
    res.json({ data: rows, summary: { total_days: totalDays, month: m, year: y }, today: todayLog || null });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch attendance' }); }
});

// GET /hr/mobile/payslip/:employee_id — Payslip history for mobile
router.get('/mobile/payslip/:employee_id', async (req: Request, res: Response) => {
  try {
    const rows = await dbAll(
      `SELECT pr.*, e.name as employee_name, e.code as employee_code, e.position
       FROM payslip_records pr JOIN employees e ON pr.employee_id=e.id
       WHERE pr.employee_id=? ORDER BY pr.period_year DESC, pr.period_month DESC LIMIT 12`,
      [req.params.employee_id]
    );
    res.json({ data: rows });
  } catch (error) { res.status(500).json({ error: 'Failed to fetch payslips' }); }
});

const generateFinanceCode = (prefix: string) => {
  const now = new Date();
  const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${datePart}-${rand}`;
};

// ===== PAYROLL REQUESTS =====

// GET /payroll-requests — list all grouped by period
router.get('/payroll-requests', authMiddleware, async (req: Request, res: Response) => {
  try {
    const rows = await dbAll(`
      SELECT pr.*,
             u.full_name as requester_name,
             COUNT(pri.id) as item_count
      FROM payroll_requests pr
      LEFT JOIN users u ON pr.requester_id = u.id
      LEFT JOIN payroll_request_items pri ON pri.payroll_request_id = pr.id
      GROUP BY pr.id
      ORDER BY pr.period_year DESC, pr.period_month DESC`);
    res.json({ data: rows });
  } catch (error: any) {
    res.status(500).json({ error: 'Failed to fetch payroll requests' });
  }
});

// POST /payroll-requests — create batch from payslip_records for a period
router.post('/payroll-requests', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { period_month, period_year, payslip_ids, purpose, notes, project_id, due_date } = req.body;
    if (!period_month || !period_year) {
      return res.status(400).json({ error: 'period_month and period_year are required' });
    }
    const userId = (req as any).user?.userId || null;

    // If specific payslip_ids provided use them, else fetch all finalized payslips for period
    let payslips: any[];
    if (payslip_ids && Array.isArray(payslip_ids) && payslip_ids.length > 0) {
      const ph = payslip_ids.map(() => '?').join(',');
      payslips = await dbAll(
        `SELECT ps.*, e.name as employee_name, e.department_id, d.name as department
         FROM payslip_records ps
         LEFT JOIN employees e ON ps.employee_id = e.id
         LEFT JOIN departments d ON e.department_id = d.id
         WHERE ps.id IN (${ph})`,
        payslip_ids
      ) as any[];
    } else {
      payslips = await dbAll(
        `SELECT ps.*, e.name as employee_name, e.department_id, d.name as department
         FROM payslip_records ps
         LEFT JOIN employees e ON ps.employee_id = e.id
         LEFT JOIN departments d ON e.department_id = d.id
         WHERE ps.period_month = ? AND ps.period_year = ?
         ORDER BY e.name ASC`,
        [period_month, period_year]
      ) as any[];
    }

    if (payslips.length === 0) {
      return res.status(400).json({ error: 'Tidak ada payslip tersimpan untuk periode ini. Simpan slip gaji karyawan terlebih dahulu.' });
    }

    // Check if payroll request already exists for this period
    const existing = await dbGet(
      'SELECT id, request_number FROM payroll_requests WHERE period_month = ? AND period_year = ? AND status NOT IN (\'rejected\')',
      [period_month, period_year]
    ) as any;
    if (existing) {
      return res.status(400).json({ error: `Pengajuan gaji untuk periode ini sudah ada: ${existing.request_number}` });
    }

    const totalAmount = payslips.reduce((sum: number, p: any) => sum + Number(p.net_salary || 0), 0);
    const dueDate = due_date || `${period_year}-${String(period_month).padStart(2,'0')}-25`;
    const requestNumber = generateFinanceCode('GJ');
    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const periodLabel = `Gaji ${monthNames[period_month - 1]} ${period_year}`;

    const result = await dbRun(
      `INSERT INTO payroll_requests (request_number, period_month, period_year, due_date, total_amount, employee_count, purpose, notes, status, approval_status, requester_id, project_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'draft', 0, ?, ?)`,
      [requestNumber, period_month, period_year, dueDate, totalAmount, payslips.length, purpose || periodLabel, notes || null, userId, project_id || null]
    );
    const payrollId = result.insertId;

    for (const ps of payslips) {
      await dbRun(
        `INSERT INTO payroll_request_items (payroll_request_id, payslip_record_id, employee_id, employee_name, department, gross_salary, total_deductions, net_salary, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [payrollId, ps.id || null, ps.employee_id, ps.employee_name, ps.department || null, Number(ps.gross_salary || 0), Number(ps.total_deductions || 0), Number(ps.net_salary || 0), ps.notes || null]
      );
    }

    res.status(201).json({
      message: `Payroll Request ${requestNumber} berhasil dibuat (${payslips.length} karyawan, Total: ${totalAmount})`,
      data: { id: payrollId, request_number: requestNumber, total_amount: totalAmount, employee_count: payslips.length }
    });
  } catch (error: any) {
    console.error('Error creating payroll request:', error);
    res.status(500).json({ error: 'Failed to create payroll request: ' + error.message });
  }
});

// PUT /payroll-requests/:id/submit
router.put('/payroll-requests/:id/submit', authMiddleware, async (req: Request, res: Response) => {
  try {
    const pr = await dbGet('SELECT * FROM payroll_requests WHERE id = ?', [req.params.id]) as any;
    if (!pr) return res.status(404).json({ error: 'Not found' });
    if (pr.status !== 'draft') return res.status(400).json({ error: 'Only draft can be submitted' });
    await dbRun("UPDATE payroll_requests SET status = 'submitted' WHERE id = ?", [req.params.id]);
    res.json({ message: 'Payroll request submitted for approval' });
  } catch (error) { res.status(500).json({ error: 'Failed to submit' }); }
});

// PUT /payroll-requests/:id/approve
router.put('/payroll-requests/:id/approve', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    const pr = await dbGet('SELECT * FROM payroll_requests WHERE id = ?', [req.params.id]) as any;
    if (!pr) return res.status(404).json({ error: 'Not found' });
    if (!['submitted', 'draft'].includes(pr.status)) {
      return res.status(400).json({ error: 'Cannot approve in current status' });
    }
    await dbRun(
      "UPDATE payroll_requests SET status = 'approved', approval_status = 1, approved_by = ?, approved_at = NOW() WHERE id = ?",
      [userId, req.params.id]
    );
    res.json({ message: 'Payroll request approved.' });
  } catch (error) { res.status(500).json({ error: 'Failed to approve' }); }
});

// PUT /payroll-requests/:id/reject
router.put('/payroll-requests/:id/reject', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun(
      "UPDATE payroll_requests SET status = 'rejected', approval_status = 0 WHERE id = ?",
      [req.params.id]
    );
    res.json({ message: 'Payroll request rejected' });
  } catch (error) { res.status(500).json({ error: 'Failed to reject' }); }
});

// DELETE /payroll-requests/:id — only draft
router.delete('/payroll-requests/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const pr = await dbGet('SELECT * FROM payroll_requests WHERE id = ?', [req.params.id]) as any;
    if (!pr) return res.status(404).json({ error: 'Not found' });
    if (!['draft', 'rejected'].includes(pr.status)) {
      return res.status(400).json({ error: 'Hanya draft/rejected yang bisa dihapus' });
    }
    await dbRun('DELETE FROM payroll_request_items WHERE payroll_request_id = ?', [req.params.id]);
    await dbRun('DELETE FROM payroll_requests WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) { res.status(500).json({ error: 'Failed to delete' }); }
});

export default router;
