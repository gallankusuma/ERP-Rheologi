import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = Router();

// Utility for generating FPA numbers
const generateFPANumber = (type: string) => {
  const now = new Date();
  const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(100 + Math.random() * 900);
  return `FPA-${type}-${datePart}-${rand}`;
};

const generateCode = (prefix: string) => {
  const now = new Date();
  const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${datePart}-${rand}`;
};

// ============================================================
// MASTER DATA
// ============================================================

// --- Parameters ---
router.get('/parameters', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll('SELECT * FROM qc_parameters ORDER BY name ASC');
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch parameters' });
  }
});

router.post('/parameters', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, description, code, param_type } = req.body;
    const result = await dbRun('INSERT INTO qc_parameters (name, description, code, param_type) VALUES (?, ?, ?, ?)', [name, description || null, code || null, param_type || 'quantitative']);
    res.status(201).json({ success: true, message: 'Parameter created', id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to create parameter' });
  }
});

router.put('/parameters/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, description, code, param_type } = req.body;
    await dbRun('UPDATE qc_parameters SET name=?, description=?, code=?, param_type=? WHERE id=?', [name, description || null, code || null, param_type || 'quantitative', req.params.id]);
    res.json({ success: true, message: 'Parameter updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update parameter' });
  }
});

router.delete('/parameters/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_parameters WHERE id=?', [req.params.id]);
    res.json({ success: true, message: 'Parameter deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete parameter' });
  }
});

// --- Methods ---
router.get('/methods', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll('SELECT * FROM qc_methods ORDER BY name ASC');
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch methods' });
  }
});

router.post('/methods', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, description } = req.body;
    const result = await dbRun('INSERT INTO qc_methods (name, description) VALUES (?, ?)', [name, description]);
    res.status(201).json({ success: true, message: 'Method created', id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to create method' });
  }
});

router.put('/methods/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, description } = req.body;
    await dbRun('UPDATE qc_methods SET name=?, description=? WHERE id=?', [name, description, req.params.id]);
    res.json({ success: true, message: 'Method updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update method' });
  }
});

router.delete('/methods/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_methods WHERE id=?', [req.params.id]);
    res.json({ success: true, message: 'Method deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete method' });
  }
});

// --- Instruments ---
router.get('/instruments', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll('SELECT * FROM qc_instruments ORDER BY name ASC');
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch instruments' });
  }
});

router.post('/instruments', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, calibration_date } = req.body;
    const result = await dbRun('INSERT INTO qc_instruments (name, calibration_date) VALUES (?, ?)', [name, calibration_date]);
    res.status(201).json({ success: true, message: 'Instrument created', id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to create instrument' });
  }
});

router.put('/instruments/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name, calibration_date } = req.body;
    await dbRun('UPDATE qc_instruments SET name=?, calibration_date=? WHERE id=?', [name, calibration_date, req.params.id]);
    res.json({ success: true, message: 'Instrument updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update instrument' });
  }
});

router.delete('/instruments/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_instruments WHERE id=?', [req.params.id]);
    res.json({ success: true, message: 'Instrument deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete instrument' });
  }
});

// --- Sampling Areas ---
router.get('/areas', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll('SELECT * FROM qc_sampling_areas ORDER BY name ASC');
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch sampling areas' });
  }
});

router.post('/areas', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name } = req.body;
    const result = await dbRun('INSERT INTO qc_sampling_areas (name) VALUES (?)', [name]);
    res.status(201).json({ success: true, message: 'Area created', id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to create area' });
  }
});

router.put('/areas/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { name } = req.body;
    await dbRun('UPDATE qc_sampling_areas SET name=? WHERE id=?', [name, req.params.id]);
    res.json({ success: true, message: 'Area updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update area' });
  }
});

router.delete('/areas/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_sampling_areas WHERE id=?', [req.params.id]);
    res.json({ success: true, message: 'Area deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete area' });
  }
});


// ============================================================
// QC SPECIFICATIONS (Per Item)
// ============================================================
router.get('/specs/:product_id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const qcType = req.query.qc_type as string || null;
    let query = `
      SELECT s.*, p.name as parameter_name, m.name as method_name
      FROM qc_specifications s
      JOIN qc_parameters p ON s.parameter_id = p.id
      LEFT JOIN qc_methods m ON s.method_id = m.id
      WHERE s.product_id = ?
    `;
    const params: any[] = [req.params.product_id];
    if (qcType) {
      query += ' AND s.qc_type = ?';
      params.push(qcType);
    }
    query += ' ORDER BY p.name ASC';
    const data = await dbAll(query, params);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch specs' });
  }
});

router.post('/specs', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { product_id, qc_type, parameter_id, method_id, standard_value, min_value, max_value, uom } = req.body;
    const result = await dbRun(
      'INSERT INTO qc_specifications (product_id, qc_type, parameter_id, method_id, standard_value, min_value, max_value, uom) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [product_id, qc_type || 'Incoming', parameter_id, method_id || null, standard_value, min_value || null, max_value || null, uom || null]
    );
    res.status(201).json({ success: true, message: 'Spec created', id: result.insertId });
  } catch (error: any) {
    console.error('Spec creation error:', error?.message || error);
    res.status(500).json({ success: false, error: 'Failed to create spec', detail: error?.message });
  }
});

router.put('/specs/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { parameter_id, method_id, standard_value, min_value, max_value, qc_type, uom } = req.body;
    await dbRun(
      'UPDATE qc_specifications SET parameter_id=?, method_id=?, standard_value=?, min_value=?, max_value=?, qc_type=?, uom=? WHERE id=?',
      [parameter_id, method_id || null, standard_value, min_value || null, max_value || null, qc_type || 'Incoming', uom || null, req.params.id]
    );
    res.json({ success: true, message: 'Spec updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update spec' });
  }
});

router.delete('/specs/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_specifications WHERE id=?', [req.params.id]);
    res.json({ success: true, message: 'Spec deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete spec' });
  }
});

// ============================================================
// ANALYSIS REQUESTS (FPA)
// ============================================================
router.get('/fpa', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll(`
      SELECT f.*, p.name as product_name, p.sku as product_sku, a.name as area_name, u.full_name as created_by_name
      FROM qc_analysis_requests f
      LEFT JOIN products p ON f.product_id = p.id
      LEFT JOIN qc_sampling_areas a ON f.sampling_area_id = a.id
      LEFT JOIN users u ON f.created_by = u.id
      ORDER BY f.created_at DESC
    `);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch FPAs' });
  }
});

router.post('/fpa', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { type, reference_id, reference_number, product_id, sampling_area_id, batch_no, quantity, supplier_id, notes } = req.body;
    const fpa_number = generateFPANumber(type || 'INC');
    const userId = (req as any).user?.userId || null;
    
    const result = await dbRun(
      'INSERT INTO qc_analysis_requests (fpa_number, type, reference_id, reference_number, product_id, sampling_area_id, batch_no, quantity, supplier_id, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [fpa_number, type || 'Incoming', reference_id || null, reference_number || null, product_id, sampling_area_id || null, batch_no || null, quantity || null, supplier_id || null, notes || null, userId]
    );
    
    // Copy specs to analysis results (filter by qc_type)
    const specs = await dbAll(
      'SELECT * FROM qc_specifications WHERE product_id = ? AND (qc_type = ? OR qc_type IS NULL)',
      [product_id, type || 'Incoming']
    );
    for (const spec of specs) {
      await dbRun(
        'INSERT INTO qc_analysis_results (fpa_id, parameter_id) VALUES (?, ?)',
        [result.insertId, spec.parameter_id]
      );
    }
    
    res.status(201).json({ success: true, message: 'FPA created', id: result.insertId, fpa_number });
  } catch (error: any) {
    console.error('FPA creation error:', error?.message || error);
    res.status(500).json({ success: false, error: 'Failed to create FPA', detail: error?.message });
  }
});

router.get('/fpa/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const fpa = await dbGet(`
      SELECT f.*, p.name as product_name, p.sku as product_sku,
        a.name as area_name,
        u.full_name as created_by_name,
        wo.wo_number, wo.status as wo_status,
        a1.full_name as approver1_name, a2.full_name as approver2_name
      FROM qc_analysis_requests f
      LEFT JOIN products p ON f.product_id = p.id
      LEFT JOIN qc_sampling_areas a ON f.sampling_area_id = a.id
      LEFT JOIN users u ON f.created_by = u.id
      LEFT JOIN work_orders wo ON f.wo_id = wo.id
      LEFT JOIN users a1 ON f.approved_by_1 = a1.id
      LEFT JOIN users a2 ON f.approved_by_2 = a2.id
      WHERE f.id = ?
    `, [req.params.id]);
    
    if (!fpa) return res.status(404).json({ success: false, error: 'FPA not found' });
    
    // Check if results exist, if not auto-populate from specs
    const existingCount = await dbGet('SELECT COUNT(*) as cnt FROM qc_analysis_results WHERE fpa_id = ?', [req.params.id]);
    if ((existingCount as any)?.cnt === 0 && (fpa as any).product_id) {
      const fpaType = (fpa as any).type || 'LP';
      const specs = await dbAll(
        'SELECT * FROM qc_specifications WHERE product_id = ? AND (qc_type = ? OR qc_type IS NULL)',
        [(fpa as any).product_id, fpaType]
      );
      // If no specs with qc_type match, try all specs for this product
      const allSpecs = specs.length > 0 ? specs : await dbAll(
        'SELECT * FROM qc_specifications WHERE product_id = ?',
        [(fpa as any).product_id]
      );
      for (const spec of allSpecs) {
        await dbRun(
          'INSERT INTO qc_analysis_results (fpa_id, parameter_id) VALUES (?, ?)',
          [req.params.id, spec.parameter_id]
        );
      }
    }

    const results = await dbAll(`
      SELECT r.*, p.name as parameter_name, p.code as parameter_code, p.param_type,
             i.name as instrument_name,
             s.standard_value as spec_std, s.min_value as spec_min, s.max_value as spec_max, s.uom,
             m.name as method_name,
             an.full_name as analyst_name
      FROM qc_analysis_results r
      JOIN qc_parameters p ON r.parameter_id = p.id
      LEFT JOIN qc_instruments i ON r.instrument_id = i.id
      LEFT JOIN qc_specifications s ON s.product_id = ? AND s.parameter_id = r.parameter_id
      LEFT JOIN qc_methods m ON s.method_id = m.id
      LEFT JOIN users an ON r.analyst_id = an.id
      WHERE r.fpa_id = ?
      ORDER BY r.id ASC
    `, [(fpa as any).product_id, req.params.id]);

    // Merge spec values: prefer result-level, fallback to spec-level
    for (const r of results as any[]) {
      r.standard_value = r.standard_value || r.spec_std;
      r.min_value = r.min_value ?? r.spec_min;
      r.max_value = r.max_value ?? r.spec_max;
    }

    // Get related FPA runs (same parent or same product+batch)
    const relatedRuns = await dbAll(`
      SELECT f.id, f.fpa_number, f.status, f.result, f.sampling_run, f.data_complete,
        f.approved_by_1, f.approved_at_1, f.approved_by_2, f.approved_at_2,
        f.needs_resampling, f.disposition, f.specification_doc, f.analysis_notes,
        a1.full_name as approver1_name, a2.full_name as approver2_name
      FROM qc_analysis_requests f
      LEFT JOIN users a1 ON f.approved_by_1 = a1.id
      LEFT JOIN users a2 ON f.approved_by_2 = a2.id
      WHERE (f.parent_fpa_id = ? OR f.id = ? OR f.parent_fpa_id = COALESCE(?, f.id))
      ORDER BY f.sampling_run ASC
    `, [req.params.id, req.params.id, (fpa as any).parent_fpa_id]);
    
    // Get instruments & analysts for dropdowns
    const instruments = await dbAll('SELECT id, name FROM qc_instruments ORDER BY name');
    const analysts = await dbAll("SELECT id, full_name as name FROM users WHERE is_active = 1 ORDER BY full_name");
    
    res.json({ success: true, data: { ...(fpa as any), results, relatedRuns, instruments, analysts } });
  } catch (error) {
    console.error('Error fetching FPA detail:', error);
    res.status(500).json({ success: false, error: 'Failed to fetch FPA detail' });
  }
});

router.put('/fpa/:id/results', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { results, status, result, notes, analysis_notes, data_complete } = req.body;
    const fpaId = req.params.id;
    
    // Update FPA header
    const updateParts: string[] = ['updated_at=CURRENT_TIMESTAMP'];
    const updateVals: any[] = [];
    if (status !== undefined) { updateParts.push('status=?'); updateVals.push(status); }
    if (result !== undefined) { updateParts.push('result=?'); updateVals.push(result); }
    if (notes !== undefined) { updateParts.push('notes=?'); updateVals.push(notes); }
    if (analysis_notes !== undefined) { updateParts.push('analysis_notes=?'); updateVals.push(analysis_notes); }
    if (data_complete !== undefined) { updateParts.push('data_complete=?'); updateVals.push(data_complete ? 1 : 0); }
    updateVals.push(fpaId);
    await dbRun(`UPDATE qc_analysis_requests SET ${updateParts.join(', ')} WHERE id=?`, updateVals);
    
    // Update individual results with saplo/duplo/analyst
    if (results && Array.isArray(results)) {
      for (const r of results) {
        await dbRun(
          `UPDATE qc_analysis_results SET
            instrument_id=COALESCE(?,instrument_id),
            actual_value=COALESCE(?,actual_value),
            saplo=COALESCE(?,saplo),
            duplo=COALESCE(?,duplo),
            analyst_id=COALESCE(?,analyst_id),
            notes=COALESCE(?,notes),
            is_pass=?
          WHERE id=?`,
          [
            r.instrument_id ?? null, r.actual_value ?? null,
            r.saplo ?? null, r.duplo ?? null,
            r.analyst_id ?? null, r.notes ?? null,
            r.is_pass === undefined ? null : r.is_pass,
            r.id
          ]
        );
      }
    }

    // Auto-update linked WO QC checkpoint
    if (status === 'Released' || status === 'Approved' || result === 'Passed' || result === 'Released') {
      const checkpoint = await dbGet('SELECT id FROM wo_qc_checkpoints WHERE fpa_id = ?', [fpaId]) as any;
      if (checkpoint) {
        const finalStatus = (result === 'Failed' || result === 'Rejected') ? 'failed' : 'passed';
        await dbRun('UPDATE wo_qc_checkpoints SET status = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?', [finalStatus, checkpoint.id]);
      }
    }
    if (result === 'Failed' || result === 'Rejected') {
      const checkpoint = await dbGet('SELECT id FROM wo_qc_checkpoints WHERE fpa_id = ?', [fpaId]) as any;
      if (checkpoint) {
        await dbRun('UPDATE wo_qc_checkpoints SET status = ?, resolved_at = CURRENT_TIMESTAMP WHERE id = ?', ['failed', checkpoint.id]);
      }
    }
    
    res.json({ success: true, message: 'FPA updated' });
  } catch (error) {
    console.error('Error updating FPA:', error);
    res.status(500).json({ success: false, error: 'Failed to update FPA' });
  }
});

// --- Receive Sample ---
router.put('/fpa/:id/receive-sample', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun(
      'UPDATE qc_analysis_requests SET status = "Sample Diterima", updated_at = CURRENT_TIMESTAMP WHERE id = ? AND status = "Pending"',
      [req.params.id]
    );
    res.json({ success: true, message: 'Sample received' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to receive sample' });
  }
});

// --- Update General Info ---
router.put('/fpa/:id/general', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { sampling_qty, sampling_unit, sampling_point, process_type, sample_type, specification_doc } = req.body;
    await dbRun(`
      UPDATE qc_analysis_requests SET
        sampling_qty=COALESCE(?,sampling_qty), sampling_unit=COALESCE(?,sampling_unit),
        sampling_point=COALESCE(?,sampling_point), process_type=COALESCE(?,process_type),
        sample_type=COALESCE(?,sample_type), specification_doc=COALESCE(?,specification_doc),
        updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `, [sampling_qty??null, sampling_unit??null, sampling_point??null, process_type??null, sample_type??null, specification_doc??null, req.params.id]);
    res.json({ success: true, message: 'General info updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update general info' });
  }
});

// --- User Area Sampling ---
router.get('/user-areas', authMiddleware, async (req: Request, res: Response) => {
  try {
    const data = await dbAll(`
      SELECT ua.id, ua.user_id, ua.area_id, u.full_name as user_name, a.name as area_name
      FROM qc_user_areas ua
      JOIN users u ON ua.user_id = u.id
      JOIN qc_sampling_areas a ON ua.area_id = a.id
      ORDER BY u.full_name ASC
    `);
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to fetch user areas' });
  }
});

router.post('/user-areas', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { user_id, area_ids } = req.body;
    // Delete existing assignments for this user
    await dbRun('DELETE FROM qc_user_areas WHERE user_id = ?', [user_id]);
    // Insert new assignments
    for (const area_id of (area_ids || [])) {
      await dbRun('INSERT INTO qc_user_areas (user_id, area_id) VALUES (?, ?)', [user_id, area_id]);
    }
    res.json({ success: true, message: 'User areas updated' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to update user areas' });
  }
});

router.delete('/user-areas/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun('DELETE FROM qc_user_areas WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'User area deleted' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to delete user area' });
  }
});

// --- FPA Approval Workflow ---
router.put('/fpa/:id/submit', authMiddleware, async (req: Request, res: Response) => {
  try {
    await dbRun(
      'UPDATE qc_analysis_requests SET status = "Review", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [req.params.id]
    );
    res.json({ success: true, message: 'FPA submitted for review' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to submit FPA' });
  }
});

// --- Dual Approval Workflow ---
router.put('/fpa/:id/approve-1', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    await dbRun(
      'UPDATE qc_analysis_requests SET approved_by_1 = ?, approved_at_1 = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [userId, req.params.id]
    );
    res.json({ success: true, message: 'Approve #1 completed' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to approve #1' });
  }
});

router.put('/fpa/:id/approve-2', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    await dbRun(
      'UPDATE qc_analysis_requests SET approved_by_2 = ?, approved_at_2 = CURRENT_TIMESTAMP, status = "Approved", result = "Pass", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [userId, req.params.id]
    );
    // Auto-update batch qc_status
    const fpa = await dbGet('SELECT * FROM qc_analysis_requests WHERE id = ?', [req.params.id]) as any;
    if (fpa?.batch_no) {
      await dbRun('UPDATE batches SET qc_status = "passed" WHERE batch_number = ?', [fpa.batch_no]);
    }
    // Auto-update WO checkpoint
    const checkpoint = await dbGet('SELECT id FROM wo_qc_checkpoints WHERE fpa_id = ?', [req.params.id]) as any;
    if (checkpoint) {
      await dbRun('UPDATE wo_qc_checkpoints SET status = "passed", resolved_at = CURRENT_TIMESTAMP WHERE id = ?', [checkpoint.id]);
    }
    res.json({ success: true, message: 'Approve #2 completed, FPA approved' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to approve #2' });
  }
});

router.put('/fpa/:id/reject', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    const { review_notes } = req.body;
    await dbRun(
      'UPDATE qc_analysis_requests SET status = "Rejected", result = "Fail", reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP, review_notes = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [userId, review_notes || null, req.params.id]
    );
    const fpa = await dbGet('SELECT * FROM qc_analysis_requests WHERE id = ?', [req.params.id]) as any;
    if (fpa?.batch_no) {
      await dbRun('UPDATE batches SET qc_status = "failed" WHERE batch_number = ?', [fpa.batch_no]);
    }
    res.json({ success: true, message: 'FPA rejected' });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Failed to reject FPA' });
  }
});

// --- Resampling: create new FPA run ---
router.post('/fpa/:id/new-run', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    const parentFpa = await dbGet('SELECT * FROM qc_analysis_requests WHERE id = ?', [req.params.id]) as any;
    if (!parentFpa) return res.status(404).json({ success: false, error: 'FPA not found' });

    // Mark parent as needing resampling
    await dbRun('UPDATE qc_analysis_requests SET needs_resampling = 1, status = "Resampling", updated_at = CURRENT_TIMESTAMP WHERE id = ?', [req.params.id]);

    // Determine next run number
    const rootId = parentFpa.parent_fpa_id || parentFpa.id;
    const maxRun = await dbGet('SELECT MAX(sampling_run) as mx FROM qc_analysis_requests WHERE id = ? OR parent_fpa_id = ?', [rootId, rootId]) as any;
    const nextRun = (maxRun?.mx || 1) + 1;

    // Create new FPA run
    const newFpaNumber = generateFPANumber(parentFpa.type || 'LP');
    const result = await dbRun(
      `INSERT INTO qc_analysis_requests (fpa_number, type, reference_id, reference_number, product_id, sampling_area_id, batch_no, quantity, supplier_id, notes, created_by, status, sampling_run, parent_fpa_id, wo_id, specification_doc, sampling_point, process_type, sample_type)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?, ?, ?, ?, ?, ?, ?)`,
      [newFpaNumber, parentFpa.type, parentFpa.reference_id, parentFpa.reference_number, parentFpa.product_id, parentFpa.sampling_area_id, parentFpa.batch_no, parentFpa.quantity, parentFpa.supplier_id, `Resampling run #${nextRun}`, userId, nextRun, rootId, parentFpa.wo_id, parentFpa.specification_doc, parentFpa.sampling_point, parentFpa.process_type, parentFpa.sample_type]
    );

    // Copy specs to new run
    const specs = await dbAll('SELECT * FROM qc_specifications WHERE product_id = ?', [parentFpa.product_id]);
    for (const spec of (specs as any[])) {
      await dbRun(
        'INSERT INTO qc_analysis_results (fpa_id, parameter_id, instrument_id, actual_value, saplo, duplo, is_pass) VALUES (?, ?, NULL, NULL, NULL, NULL, NULL)',
        [result.insertId, spec.parameter_id]
      );
    }

    res.status(201).json({ success: true, message: `Resampling run #${nextRun} created`, id: result.insertId, fpa_number: newFpaNumber });
  } catch (error) {
    console.error('Error creating resampling run:', error);
    res.status(500).json({ success: false, error: 'Failed to create resampling run' });
  }
});

// --- Raise NCR from FPA ---
router.post('/fpa/:id/raise-ncr', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    const fpa = await dbGet('SELECT * FROM qc_analysis_requests WHERE id = ?', [req.params.id]) as any;
    if (!fpa) return res.status(404).json({ success: false, error: 'FPA not found' });

    const ncr_number = generateCode('NCR');
    const { category, severity, description, root_cause } = req.body;

    const descText = description || `Non-Conformance raised from FPA ${fpa.fpa_number} (Batch: ${fpa.batch_no || 'N/A'})`;

    const result = await dbRun(
      `INSERT INTO qc_ncr (ncr_number, product_id, category, severity, description, root_cause, status, reported_by)
       VALUES (?, ?, ?, ?, ?, ?, 'open', ?)`,
      [ncr_number, fpa.product_id, category || 'product', severity || 'major', descText, root_cause || null, userId]
    );

    res.status(201).json({ success: true, message: 'NCR raised successfully', id: result.insertId, ncr_number });
  } catch (error) {
    console.error('Error raising NCR:', error);
    res.status(500).json({ success: false, error: 'Failed to raise NCR' });
  }
});

// --- Request Rework from FPA ---
router.post('/fpa/:id/request-rework', authMiddleware, async (req: Request, res: Response) => {
  try {
    const userId = (req as any).user?.userId || null;
    const fpa = await dbGet('SELECT * FROM qc_analysis_requests WHERE id = ?', [req.params.id]) as any;
    if (!fpa) return res.status(404).json({ success: false, error: 'FPA not found' });

    const rework_number = generateCode('RWK');
    const { quantity, description, instructions } = req.body;

    const descText = description || `Rework requested from FPA ${fpa.fpa_number} (Batch: ${fpa.batch_no || 'N/A'})`;

    const result = await dbRun(
      `INSERT INTO qc_rework_orders (rework_number, product_id, quantity, description, instructions, status, created_by)
       VALUES (?, ?, ?, ?, ?, 'pending', ?)`,
      [rework_number, fpa.product_id, quantity || fpa.quantity || 1, descText, instructions || null, userId]
    );

    res.status(201).json({ success: true, message: 'Rework order created successfully', id: result.insertId, rework_number });
  } catch (error) {
    console.error('Error requesting rework:', error);
    res.status(500).json({ success: false, error: 'Failed to request rework' });
  }
});

export default router;
