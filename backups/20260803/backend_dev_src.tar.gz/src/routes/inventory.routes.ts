import { Router, Request, Response } from 'express';
import { dbAll, dbGet, dbRun } from '../config/database';
import { authMiddleware } from '../middleware/auth';

const router = Router();

const generateCode = (prefix: string) => {
  const now = new Date();
  const datePart = now.toISOString().slice(0, 10).replace(/-/g, '');
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${datePart}-${rand}`;
};

// ========================================
// NOTE: Specific routes are defined first.
// Generic inventory routes are declared later.
// ========================================

// ========================================
// STOCK TRANSFERS (Warehouse to Warehouse)
// ========================================

// GET /api/inventory/stock-transfers - List all stock transfers
router.get('/stock-transfers', authMiddleware, async (req: Request, res: Response) => {
  try {
    const transfers = await dbAll(`
      SELECT 
        st.*,
        p.name as product_name,
        p.sku,
        wh_from.name as from_warehouse_name,
        wh_to.name as to_warehouse_name,
        COALESCE(u.full_name, u.username) as created_by_name
      FROM stock_transfers st
      JOIN products p ON st.product_id = p.id
      JOIN warehouses wh_from ON st.from_warehouse_id = wh_from.id
      JOIN warehouses wh_to ON st.to_warehouse_id = wh_to.id
      LEFT JOIN users u ON st.created_by = u.id
      ORDER BY st.created_at DESC
    `, []);
    res.json({ data: transfers });
  } catch (error) {
    console.error('Error fetching stock transfers:', error);
    res.status(500).json({ error: 'Failed to fetch stock transfers' });
  }
});

// POST /api/inventory/stock-transfers - Create stock transfer
router.post('/stock-transfers', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { product_id, from_warehouse_id, to_warehouse_id, quantity, notes } = req.body;
    const userId = (req as any).user?.userId;

    if (!product_id || !from_warehouse_id || !to_warehouse_id || !quantity) {
      return res.status(400).json({ error: 'product_id, from_warehouse_id, to_warehouse_id, and quantity are required' });
    }

    if (Number(from_warehouse_id) === Number(to_warehouse_id)) {
      return res.status(400).json({ error: 'Source and destination warehouses must be different' });
    }

    const transferNumber = `TRF-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;

    const result = await dbRun(`
      INSERT INTO stock_transfers (transfer_number, product_id, from_warehouse_id, to_warehouse_id, quantity, status, notes, created_by)
      VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)
    `, [transferNumber, product_id, from_warehouse_id, to_warehouse_id, quantity, notes || null, userId || null]) as any;

    res.status(201).json({
      message: 'Stock transfer created successfully (Pending Approval)',
      data: { id: result.insertId || result.lastID, transfer_number: transferNumber, status: 'pending' }
    });
  } catch (error) {
    console.error('Error creating stock transfer:', error);
    res.status(500).json({ error: 'Failed to create stock transfer' });
  }
});

// PUT /api/inventory/stock-transfers/:id - Update stock transfer (only if pending)
router.put('/stock-transfers/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { quantity, notes } = req.body;

    const current = await dbGet('SELECT status FROM stock_transfers WHERE id = ?', [id]) as any;
    if (!current) return res.status(404).json({ error: 'Stock transfer not found' });
    if (current.status !== 'pending') return res.status(400).json({ error: 'Cannot edit non-pending stock transfer' });

    await dbRun('UPDATE stock_transfers SET quantity = ?, notes = ? WHERE id = ?', [quantity, notes, id]);
    res.json({ message: 'Stock transfer updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update stock transfer' });
  }
});

// DELETE /api/inventory/stock-transfers/:id
router.delete('/stock-transfers/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const current = await dbGet('SELECT status FROM stock_transfers WHERE id = ?', [id]) as any;
    if (!current) return res.status(404).json({ error: 'Stock transfer not found' });
    if (current.status !== 'pending') return res.status(400).json({ error: 'Cannot delete approved transfer' });
    await dbRun('DELETE FROM stock_transfers WHERE id = ?', [id]);
    res.json({ message: 'Stock transfer deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete stock transfer' });
  }
});

// POST /api/inventory/stock-transfers/:id/approve - Approve stock transfer
router.post('/stock-transfers/:id/approve', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.userId;

    const transfer = await dbGet('SELECT * FROM stock_transfers WHERE id = ?', [id]) as any;
    if (!transfer) return res.status(404).json({ error: 'Stock transfer not found' });
    if (transfer.status !== 'pending') return res.status(400).json({ error: 'Transfer already processed' });

    // Execute the physical stock movement
    await executeStockTransfer(transfer);

    await dbRun(
      'UPDATE stock_transfers SET status = ?, approved_by = ?, approved_at = CURRENT_TIMESTAMP WHERE id = ?',
      ['approved', userId, id]
    );

    res.json({ message: 'Stock transfer approved and executed', status: 'approved' });
  } catch (error) {
    console.error('Error approving stock transfer:', error);
    res.status(500).json({ error: 'Failed to approve stock transfer' });
  }
});

// POST /api/inventory/stock-transfers/:id/reject
router.post('/stock-transfers/:id/reject', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const transfer = await dbGet('SELECT status FROM stock_transfers WHERE id = ?', [id]) as any;
    if (!transfer) return res.status(404).json({ error: 'Stock transfer not found' });
    if (transfer.status !== 'pending') return res.status(400).json({ error: 'Transfer already processed' });

    await dbRun('UPDATE stock_transfers SET status = ? WHERE id = ?', ['rejected', id]);
    res.json({ message: 'Stock transfer rejected', status: 'rejected' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to reject stock transfer' });
  }
});

// Helper: Execute physical stock movement between warehouses
async function executeStockTransfer(transfer: any) {
  const { product_id, from_warehouse_id, to_warehouse_id, quantity } = transfer;

  // Deduct from source
  const sourceInv = await dbGet(
    'SELECT * FROM inventory_stocks WHERE product_id = ? AND warehouse_id = ?',
    [product_id, from_warehouse_id]
  ) as any;
  if (sourceInv) {
    await dbRun(
      'UPDATE inventory_stocks SET quantity = quantity - ?, last_updated = CURRENT_TIMESTAMP WHERE product_id = ? AND warehouse_id = ?',
      [quantity, product_id, from_warehouse_id]
    );
  }

  // Add to destination
  const destInv = await dbGet(
    'SELECT * FROM inventory_stocks WHERE product_id = ? AND warehouse_id = ?',
    [product_id, to_warehouse_id]
  ) as any;
  if (destInv) {
    await dbRun(
      'UPDATE inventory_stocks SET quantity = quantity + ?, last_updated = CURRENT_TIMESTAMP WHERE product_id = ? AND warehouse_id = ?',
      [quantity, product_id, to_warehouse_id]
    );
  } else {
    await dbRun(
      'INSERT INTO inventory_stocks (product_id, warehouse_id, quantity) VALUES (?, ?, ?)',
      [product_id, to_warehouse_id, quantity]
    );
  }

  // Record movement log
  await dbRun(
    `INSERT INTO stock_movements (warehouse_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_by)
     VALUES (?, ?, 'out', ?, 'stock_transfer', ?, 'Transfer out', ?)`,
    [from_warehouse_id, product_id, quantity, transfer.id, transfer.created_by]
  );
  await dbRun(
    `INSERT INTO stock_movements (warehouse_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_by)
     VALUES (?, ?, 'in', ?, 'stock_transfer', ?, 'Transfer in', ?)`,
    [to_warehouse_id, product_id, quantity, transfer.id, transfer.created_by]
  );

  console.log('✅ Stock transfer execution completed');
}



// ========================================
// STOCK ADJUSTMENTS (Manual Corrections)
// ========================================

// GET /api/inventory/stock-adjustments - List all stock adjustments
router.get('/stock-adjustments', authMiddleware, async (req: Request, res: Response) => {
  try {
    const adjustments = await dbAll(`
      SELECT 
        sm.*,
        p.name as product_name,
        p.sku,
        wh.name as warehouse_name,
        u.full_name as created_by_name
      FROM stock_movements sm
      JOIN products p ON sm.product_id = p.id
      LEFT JOIN warehouses wh ON sm.warehouse_id = wh.id
      LEFT JOIN users u ON sm.created_by = u.id
      WHERE sm.movement_type = 'adjustment'
      ORDER BY sm.created_at DESC
    `, []);
    res.json({ data: adjustments });
  } catch (error) {
    console.error('Error fetching stock adjustments:', error);
    res.status(500).json({ error: 'Failed to fetch stock adjustments' });
  }
});

// POST /api/inventory/stock-adjustments - Create stock adjustment
router.post('/stock-adjustments', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { 
      product_id, 
      warehouse_id, 
      location_id,
      batch_id,
      quantity, // Can be positive or negative
      uom,
      reason,
      notes 
    } = req.body;
    const userId = (req as any).user?.userId;

    if (!product_id || !warehouse_id || quantity === undefined || quantity === null) {
      return res.status(400).json({ error: 'product_id, warehouse_id, and quantity are required' });
    }

    const reference_id = generateCode('ADJ');
    const adjustmentType = quantity >= 0 ? 'increase' : 'decrease';

    const result = await dbRun(`
      INSERT INTO stock_movements (
        product_id, warehouse_id, location_id, batch_id,
        movement_type, transfer_type, quantity, uom,
        reference_type, reference_id, notes, created_by,
        approval_status
      ) VALUES (?, ?, ?, ?, 'adjustment', ?, ?, ?, 'stock_adjustment', ?, ?, ?, 0)
    `, [
      product_id,
      warehouse_id,
      location_id || null,
      batch_id || null,
      adjustmentType,
      quantity,
      uom || null,
      reference_id,
      reason ? `${reason} - ${notes || ''}` : notes || null,
      userId || null
    ]);

    res.status(201).json({
      message: 'Stock adjustment created successfully (Pending Approval)',
      data: { 
        id: result.insertId, 
        reference_id,
        approval_status: 0 
      }
    });
  } catch (error) {
    console.error('Error creating stock adjustment:', error);
    res.status(500).json({ error: 'Failed to create stock adjustment' });
  }
});

// DELETE /api/inventory/stock-adjustments/:id - Delete stock adjustment
router.delete('/stock-adjustments/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    const current = await dbGet('SELECT approval_status FROM stock_movements WHERE id = ?', [id]) as any;
    if (!current) {
      return res.status(404).json({ error: 'Stock adjustment not found' });
    }

    if (current.approval_status !== 0) {
      return res.status(400).json({ error: 'Cannot delete approved stock adjustment. Use reject instead.' });
    }

    await dbRun('DELETE FROM stock_movements WHERE id = ?', [id]);
    res.json({ message: 'Stock adjustment deleted successfully' });
  } catch (error) {
    console.error('Error deleting stock adjustment:', error);
    res.status(500).json({ error: 'Failed to delete stock adjustment' });
  }
});

// POST /api/inventory/stock-adjustments/:id/approve - Approve stock adjustment
router.post('/stock-adjustments/:id/approve', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userId = (req as any).user?.userId;
    const userLevel = (req as any).user?.userLevel || 1;

    if (!userId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const adjustment = await dbGet('SELECT * FROM stock_movements WHERE id = ?', [id]) as any;
    if (!adjustment) {
      return res.status(404).json({ error: 'Stock adjustment not found' });
    }

    const currentStatus = adjustment.approval_status || 0;

    // Director & Master (Level 4+) - DIRECT APPROVAL
    if (userLevel >= 4) {
      const approverRow = await dbGet('SELECT id FROM users WHERE id = ?', [userId]) as { id: number } | undefined;
      const approverId = approverRow ? userId : null;

      await dbRun(
        'UPDATE stock_movements SET approval_status = 2, approved_by_supervisor_id = ?, approved_by_manager_id = ?, approved_at_supervisor = CURRENT_TIMESTAMP, approved_at_manager = CURRENT_TIMESTAMP WHERE id = ?',
        [approverId, approverId, id]
      );

      await executeStockAdjustment(adjustment);

      return res.json({ message: 'Stock adjustment fully approved and executed', approval_status: 2 });
    }

    // Supervisor (Level 2)
    if (userLevel === 2 && currentStatus === 0) {
      await dbRun(
        'UPDATE stock_movements SET approval_status = 1, approved_by_supervisor_id = ?, approved_at_supervisor = CURRENT_TIMESTAMP WHERE id = ?',
        [userId, id]
      );
      return res.json({ message: 'Stock adjustment approved by supervisor (1/2)', approval_status: 1 });
    }

    // Manager (Level 3)
    if (userLevel === 3 && currentStatus === 1) {
      await dbRun(
        'UPDATE stock_movements SET approval_status = 2, approved_by_manager_id = ?, approved_at_manager = CURRENT_TIMESTAMP WHERE id = ?',
        [userId, id]
      );

      await executeStockAdjustment(adjustment);

      return res.json({ message: 'Stock adjustment fully approved and executed (2/2)', approval_status: 2 });
    }

    return res.status(403).json({ error: 'Not authorized to approve at this level' });
  } catch (error) {
    console.error('Error approving stock adjustment:', error);
    res.status(500).json({ error: 'Failed to approve stock adjustment' });
  }
});

// POST /api/inventory/stock-adjustments/:id/reject - Reject stock adjustment
router.post('/stock-adjustments/:id/reject', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const userLevel = (req as any).user?.userLevel || 1;

    const adjustment = await dbGet('SELECT approval_status FROM stock_movements WHERE id = ?', [id]) as any;
    if (!adjustment) {
      return res.status(404).json({ error: 'Stock adjustment not found' });
    }

    const currentStatus = adjustment.approval_status || 0;

    if (userLevel < 2 || currentStatus === 0) {
      return res.status(403).json({ error: 'Not authorized to reject' });
    }

    if (userLevel < 4 && currentStatus !== 1) {
      return res.status(403).json({ error: 'Not authorized to reject at this level' });
    }

    await dbRun(
      'UPDATE stock_movements SET approval_status = 0, approved_by_supervisor_id = NULL, approved_by_manager_id = NULL, approved_at_supervisor = NULL, approved_at_manager = NULL WHERE id = ?',
      [id]
    );

    res.json({ message: 'Stock adjustment reset to pending (0/2)', approval_status: 0 });
  } catch (error) {
    console.error('Error rejecting stock adjustment:', error);
    res.status(500).json({ error: 'Failed to reject stock adjustment' });
  }
});

// ========================================
// GENERIC INVENTORY ROUTES (AFTER stock-* routes)
// ========================================

// GET /api/inventory - List all inventory
router.get('/', authMiddleware, async (_req: Request, res: Response) => {
  try {
    const inventory = await dbAll(
      `SELECT i.id,
              i.product_id,
              p.name as product_name,
              p.sku,
              i.quantity as quantity_on_hand,
              0 as quantity_reserved,
              i.quantity as quantity_available,
              w.name as location,
              i.last_updated as created_at
       FROM inventory_stocks i
       JOIN products p ON i.product_id = p.id
       JOIN warehouses w ON i.warehouse_id = w.id
       ORDER BY p.name ASC`,
      []
    );
    res.json({ data: inventory });
  } catch (error) {
    console.error('Error fetching inventory:', error);
    res.status(500).json({ error: 'Failed to fetch inventory' });
  }
});

// GET /api/inventory/:id - Get single inventory item (numeric ID only — named paths handled by specific routes below)
router.get('/:id', authMiddleware, async (req: Request, res: Response, next: any) => {
  // If id is not a number, pass to next matching route (kpi, expiry, opname, batch-tracking, etc.)
  if (isNaN(Number(req.params.id))) return next();
  try {
    const item = await dbGet(`
      SELECT i.*, p.name as product_name, p.sku 
      FROM inventory_stocks i 
      JOIN products p ON i.product_id = p.id 
      WHERE i.id = ?
    `, [req.params.id]);
    
    if (!item) {
      return res.status(404).json({ error: 'Inventory item not found' });
    }
    
    res.json({ data: item });
  } catch (error) {
    console.error('Error fetching inventory item:', error);
    res.status(500).json({ error: 'Failed to fetch inventory item' });
  }
});

// POST /api/inventory - Create inventory entry
router.post('/', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { product_id, warehouse_id, quantity } = req.body;

    if (!product_id || !warehouse_id) {
      return res.status(400).json({ error: 'product_id and warehouse_id are required' });
    }

    // Check if inventory already exists for this product/warehouse combo
    const existing = await dbGet(
      'SELECT * FROM inventory_stocks WHERE product_id = ? AND warehouse_id = ?',
      [product_id, warehouse_id]
    );
    if (existing) {
      return res.status(400).json({ error: 'Inventory already exists for this product-warehouse combination' });
    }

    const result = await dbRun(`
      INSERT INTO inventory_stocks (product_id, warehouse_id, quantity, last_updated) 
      VALUES (?, ?, ?, CURRENT_TIMESTAMP)
    `, [product_id, warehouse_id, quantity || 0]);

    res.status(201).json({
      message: 'Inventory created successfully',
      data: { id: result.insertId, product_id, warehouse_id, quantity: quantity || 0 },
    });
  } catch (error) {
    console.error('Error creating inventory:', error);
    res.status(500).json({ error: 'Failed to create inventory' });
  }
});

// PUT /api/inventory/:id - Update inventory
router.put('/:id', authMiddleware, async (req: Request, res: Response, next: any) => {
  if (isNaN(Number(req.params.id))) return next();
  try {
    const { quantity } = req.body;

    await dbRun(`
      UPDATE inventory_stocks 
      SET quantity = ?, last_updated = CURRENT_TIMESTAMP 
      WHERE id = ?
    `, [quantity, req.params.id]);

    res.json({ message: 'Inventory updated successfully' });
  } catch (error) {
    console.error('Error updating inventory:', error);
    res.status(500).json({ error: 'Failed to update inventory' });
  }
});

// POST /api/inventory/:id/transaction - Record inventory transaction
router.post('/:id/transaction', authMiddleware, async (req: Request, res: Response, next: any) => {
  if (isNaN(Number(req.params.id))) return next();
  try {
    const { transaction_type, quantity, reference_type, reference_id, notes } = req.body;

    if (!transaction_type || !quantity) {
      return res.status(400).json({ error: 'transaction_type and quantity are required' });
    }

    const result = await dbRun(`
      INSERT INTO stock_movements (product_id, warehouse_id, movement_type, quantity, reference_type, reference_id, notes, created_by) 
      SELECT product_id, warehouse_id, ?, ?, ?, ?, ?, NULL FROM inventory_stocks WHERE id = ?
    `, [transaction_type, quantity, reference_type || null, reference_id || null, notes || null, req.params.id]);

    res.status(201).json({
      message: 'Transaction recorded successfully',
      data: { id: result.insertId },
    });
  } catch (error) {
    console.error('Error recording transaction:', error);
    res.status(500).json({ error: 'Failed to record transaction' });
  }
});

// GET /api/inventory/transactions/:productId - List transactions by product
router.get('/transactions/:productId', authMiddleware, async (req: Request, res: Response) => {
  try {
    const productId = Number(req.params.productId);
    if (!productId) {
      return res.status(400).json({ error: 'Invalid productId' });
    }

    const rows = await dbAll(`
      SELECT 
        sm.id,
        sm.product_id,
        sm.warehouse_id,
        sm.movement_type as transaction_type,
        sm.quantity,
        sm.reference_type,
        sm.reference_id,
        sm.notes,
        sm.created_at AS transaction_date
      FROM stock_movements sm
      WHERE sm.product_id = ?
      ORDER BY sm.created_at DESC
    `, [productId]);
    res.json({ data: rows });
  } catch (error) {
    console.error('Error fetching inventory transactions:', error);
    res.status(500).json({ error: 'Failed to fetch inventory transactions' });
  }
});

// Helper function to execute stock adjustment
async function executeStockAdjustment(adjustment: any) {
  try {
    console.log('📊 Executing stock adjustment:', adjustment);

    const inv = await dbGet(`
      SELECT * FROM inventory_stocks 
      WHERE product_id = ? AND warehouse_id = ?
    `, [adjustment.product_id, adjustment.warehouse_id]) as any;

    if (inv) {
      const newQty = (inv.quantity || 0) + adjustment.quantity; // quantity can be negative
      await dbRun(`
        UPDATE inventory_stocks 
        SET quantity = ?, last_updated = CURRENT_TIMESTAMP 
        WHERE id = ?
      `, [newQty, inv.id]);
      console.log(`✅ Adjusted inventory by ${adjustment.quantity} (new qty: ${newQty})`);
    } else {
      // Create new inventory record if positive adjustment
      if (adjustment.quantity > 0) {
        await dbRun(`
          INSERT INTO inventory_stocks (product_id, warehouse_id, quantity, last_updated)
          VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        `, [adjustment.product_id, adjustment.warehouse_id, adjustment.quantity]);
        console.log(`✅ Created new inventory record with quantity ${adjustment.quantity}`);
      }
    }

    console.log('✅ Stock adjustment execution completed');
  } catch (error) {
    console.error('❌ Error executing stock adjustment:', error);
    throw error;
  }
}


// ============================================================
// INVENTORY KPI DASHBOARD
// ============================================================
router.get('/kpi', authMiddleware, async (_req: Request, res: Response) => {
  try {
    // Summary totals
    const summary = await dbGet(`
      SELECT
        COUNT(DISTINCT is2.product_id) AS total_skus,
        SUM(is2.quantity) AS total_quantity,
        SUM(is2.quantity * COALESCE(p.standard_cost, 0)) AS total_valuation,
        COUNT(DISTINCT is2.warehouse_id) AS total_warehouses,
        SUM(CASE WHEN is2.quantity <= is2.reorder_point AND is2.reorder_point > 0 THEN 1 ELSE 0 END) AS low_stock_count,
        SUM(CASE WHEN is2.quantity = 0 THEN 1 ELSE 0 END) AS out_of_stock_count
      FROM inventory_stocks is2
      JOIN products p ON p.id = is2.product_id
      WHERE p.active = 1
    `) as any;

    // Low stock items
    const lowStock = await dbAll(`
      SELECT p.name, p.sku, is2.quantity, is2.reorder_point,
             w.name AS warehouse_name,
             (is2.reorder_point - is2.quantity) AS deficit
      FROM inventory_stocks is2
      JOIN products p ON p.id = is2.product_id
      JOIN warehouses w ON w.id = is2.warehouse_id
      WHERE is2.quantity <= is2.reorder_point AND is2.reorder_point > 0 AND p.active = 1
      ORDER BY (is2.reorder_point - is2.quantity) DESC
      LIMIT 10
    `) as any[];

    // By warehouse
    const byWarehouse = await dbAll(`
      SELECT w.name AS warehouse_name, COUNT(DISTINCT is2.product_id) AS products,
             SUM(is2.quantity) AS total_qty,
             SUM(is2.quantity * COALESCE(p.standard_cost, 0)) AS valuation
      FROM inventory_stocks is2
      JOIN warehouses w ON w.id = is2.warehouse_id
      JOIN products p ON p.id = is2.product_id
      GROUP BY w.id, w.name
      ORDER BY valuation DESC
    `) as any[];

    // Top 10 by value
    const topItems = await dbAll(`
      SELECT p.name, p.sku, SUM(is2.quantity) AS quantity,
             SUM(is2.quantity * COALESCE(p.standard_cost, 0)) AS value
      FROM inventory_stocks is2
      JOIN products p ON p.id = is2.product_id
      WHERE p.active = 1
      GROUP BY p.id, p.name, p.sku
      ORDER BY value DESC
      LIMIT 10
    `) as any[];

    // Expiry alerts (batches expiring within 90 days)
    const expiryAlerts = await dbAll(`
      SELECT b.batch_number, p.name AS product_name, p.sku,
             b.quantity, b.expiry_date,
             DATEDIFF(b.expiry_date, CURDATE()) AS days_to_expiry,
             w.name AS warehouse_name
      FROM batches b
      JOIN products p ON p.id = b.product_id
      LEFT JOIN warehouses w ON w.id = b.warehouse_id
      WHERE b.expiry_date IS NOT NULL
        AND b.status = 'ACTIVE'
        AND b.quantity > 0
        AND b.expiry_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY)
      ORDER BY b.expiry_date ASC
      LIMIT 10
    `) as any[];

    // Recent movements (last 7 days)
    const recentMovements = await dbAll(`
      SELECT DATE(sm.created_at) AS date,
             SUM(CASE WHEN sm.movement_type IN ('in','receipt','purchase') THEN sm.quantity ELSE 0 END) AS inbound,
             SUM(CASE WHEN sm.movement_type IN ('out','issue','sale') THEN sm.quantity ELSE 0 END) AS outbound
      FROM stock_movements sm
      WHERE sm.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
      GROUP BY DATE(sm.created_at)
      ORDER BY date ASC
    `) as any[];

    res.json({ data: { summary, lowStock, byWarehouse, topItems, expiryAlerts, recentMovements } });
  } catch (error) {
    console.error('Inventory KPI error:', error);
    res.status(500).json({ error: 'Failed to load inventory KPI' });
  }
});

// ============================================================
// EXPIRY MONITORING
// ============================================================
router.get('/expiry', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { days = 90, status } = req.query as any;
    const batches = await dbAll(`
      SELECT b.id, b.batch_number, b.quantity, b.manufacture_date, b.expiry_date, b.status,
             p.name AS product_name, p.sku AS product_sku,
             w.name AS warehouse_name,
             DATEDIFF(b.expiry_date, CURDATE()) AS days_to_expiry,
             CASE
               WHEN b.expiry_date < CURDATE() THEN 'expired'
               WHEN DATEDIFF(b.expiry_date, CURDATE()) <= 30 THEN 'critical'
               WHEN DATEDIFF(b.expiry_date, CURDATE()) <= 90 THEN 'warning'
               ELSE 'ok'
             END AS expiry_status
      FROM batches b
      JOIN products p ON p.id = b.product_id
      LEFT JOIN warehouses w ON w.id = b.warehouse_id
      WHERE b.expiry_date IS NOT NULL AND b.quantity > 0
        AND (? IS NULL OR b.expiry_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY))
      ORDER BY b.expiry_date ASC
    `, [days || null, days || null]) as any[];

    const stats = {
      expired: batches.filter((b: any) => b.expiry_status === 'expired').length,
      critical: batches.filter((b: any) => b.expiry_status === 'critical').length,
      warning: batches.filter((b: any) => b.expiry_status === 'warning').length,
      ok: batches.filter((b: any) => b.expiry_status === 'ok').length,
    };

    res.json({ data: { batches, stats } });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load expiry data' });
  }
});

// ============================================================
// BATCH TRACKING
// ============================================================
router.get('/batch-tracking', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { search } = req.query as any;
    const batches = await dbAll(`
      SELECT b.id, b.batch_number, b.quantity, b.manufacture_date, b.expiry_date, b.status,
             p.name AS product_name, p.sku AS product_sku,
             w.name AS warehouse_name,
             (SELECT COUNT(1) FROM stock_movements sm WHERE sm.batch_number = b.batch_number) AS movement_count,
             (SELECT MAX(sm.created_at) FROM stock_movements sm WHERE sm.batch_number = b.batch_number) AS last_movement
      FROM batches b
      JOIN products p ON p.id = b.product_id
      LEFT JOIN warehouses w ON w.id = b.warehouse_id
      WHERE (? IS NULL OR b.batch_number LIKE ? OR p.name LIKE ? OR p.sku LIKE ?)
      ORDER BY b.created_at DESC
      LIMIT 100
    `, [search || null, `%${search}%`, `%${search}%`, `%${search}%`]) as any[];

    res.json({ data: batches });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load batch tracking' });
  }
});

router.get('/batch-tracking/:batchNumber/movements', authMiddleware, async (req: Request, res: Response) => {
  try {
    const movements = await dbAll(`
      SELECT sm.*, p.name AS product_name, w.name AS warehouse_name,
             COALESCE(u.full_name, u.username) AS created_by_name
      FROM stock_movements sm
      LEFT JOIN products p ON p.id = sm.product_id
      LEFT JOIN warehouses w ON w.id = sm.warehouse_id
      LEFT JOIN users u ON u.id = sm.created_by
      WHERE sm.batch_number = ?
      ORDER BY sm.created_at DESC
    `, [req.params.batchNumber]) as any[];
    res.json({ data: movements });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load batch movements' });
  }
});

// ============================================================
// STOCK OPNAME
// ============================================================
router.get('/opname', authMiddleware, async (_req: Request, res: Response) => {
  try {
    const sessions = await dbAll(`
      SELECT so.*, w.name AS warehouse_name,
             COALESCE(u.full_name, u.username) AS created_by_name,
             (SELECT COUNT(1) FROM stock_opname_items soi WHERE soi.opname_id = so.id) AS item_count,
             (SELECT COUNT(1) FROM stock_opname_items soi WHERE soi.opname_id = so.id AND soi.actual_qty IS NOT NULL) AS counted_items
      FROM stock_opname so
      LEFT JOIN warehouses w ON w.id = so.warehouse_id
      LEFT JOIN users u ON u.id = so.created_by
      ORDER BY so.created_at DESC
    `) as any[];
    res.json({ data: sessions });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load opname sessions' });
  }
});

router.post('/opname', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { warehouse_id, notes } = req.body;
    const userId = (req as any).user?.userId;
    const opnameNumber = `SO-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`;

    const result = await dbRun(
      `INSERT INTO stock_opname (opname_number, warehouse_id, status, notes, created_by) VALUES (?, ?, 'draft', ?, ?)`,
      [opnameNumber, warehouse_id, notes || null, userId]
    ) as any;
    const opnameId = result.lastID || result.insertId;

    // Auto-populate items from inventory_stocks for this warehouse
    const stocks = await dbAll(
      `SELECT product_id, quantity AS system_qty FROM inventory_stocks WHERE warehouse_id = ?`,
      [warehouse_id]
    ) as any[];

    for (const s of stocks) {
      await dbRun(
        `INSERT INTO stock_opname_items (opname_id, product_id, system_qty, actual_qty) VALUES (?, ?, ?, NULL)`,
        [opnameId, s.product_id, s.system_qty]
      );
    }

    res.json({ success: true, opname_id: opnameId, opname_number: opnameNumber, items_generated: stocks.length });
  } catch (error) {
    console.error('Create opname error:', error);
    res.status(500).json({ error: 'Failed to create opname session' });
  }
});

router.get('/opname/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const opname = await dbGet(
      `SELECT so.*, w.name AS warehouse_name FROM stock_opname so LEFT JOIN warehouses w ON w.id = so.warehouse_id WHERE so.id = ?`,
      [req.params.id]
    ) as any;
    if (!opname) return res.status(404).json({ error: 'Opname session not found' });

    const items = await dbAll(`
      SELECT soi.*, p.name AS product_name, p.sku AS product_sku, u.name AS uom_name,
             (soi.actual_qty - soi.system_qty) AS variance
      FROM stock_opname_items soi
      JOIN products p ON p.id = soi.product_id
      LEFT JOIN uom u ON u.id = p.unit_of_measure_id
      WHERE soi.opname_id = ?
      ORDER BY p.name ASC
    `, [req.params.id]) as any[];

    res.json({ data: { ...opname, items } });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load opname detail' });
  }
});

router.put('/opname/:id/items', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { items } = req.body as { items: { id: number; actual_qty: number; notes?: string }[] };
    for (const item of items) {
      await dbRun(
        `UPDATE stock_opname_items SET actual_qty = ?, notes = ? WHERE id = ? AND opname_id = ?`,
        [item.actual_qty, item.notes || null, item.id, req.params.id]
      );
    }
    res.json({ success: true, updated: items.length });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update opname items' });
  }
});

router.post('/opname/:id/post', authMiddleware, async (req: Request, res: Response) => {
  try {
    const opname = await dbGet(`SELECT * FROM stock_opname WHERE id = ? AND status = 'draft'`, [req.params.id]) as any;
    if (!opname) return res.status(400).json({ error: 'Opname not found or already posted' });
    const userId = (req as any).user?.userId;

    const items = await dbAll(
      `SELECT * FROM stock_opname_items WHERE opname_id = ? AND actual_qty IS NOT NULL`,
      [req.params.id]
    ) as any[];

    let adjusted = 0;
    for (const item of items) {
      const variance = Number(item.actual_qty) - Number(item.system_qty);
      if (Math.abs(variance) > 0.001) {
        // Apply stock adjustment
        await dbRun(
          `UPDATE inventory_stocks SET quantity = actual_qty WHERE opname_id_ref = ? AND product_id = ?`,
          [req.params.id, item.product_id]
        ).catch(() => null);

        await dbRun(
          `UPDATE inventory_stocks SET quantity = ?, last_updated = CURRENT_TIMESTAMP WHERE product_id = ? AND warehouse_id = ?`,
          [item.actual_qty, item.product_id, opname.warehouse_id]
        );

        await dbRun(
          `INSERT INTO stock_movements (warehouse_id, product_id, movement_type, quantity, reference_type, reference_id, notes, created_by)
           VALUES (?, ?, 'adjustment', ?, 'stock_opname', ?, ?, ?)`,
          [opname.warehouse_id, item.product_id, Math.abs(variance),
           req.params.id, `Opname adjustment: ${variance > 0 ? '+' : ''}${variance}`, userId]
        );
        adjusted++;
      }
    }

    await dbRun(
      `UPDATE stock_opname SET status = 'posted', posted_at = CURRENT_TIMESTAMP, posted_by = ? WHERE id = ?`,
      [userId, req.params.id]
    );

    res.json({ success: true, adjusted_items: adjusted });
  } catch (error) {
    console.error('Post opname error:', error);
    res.status(500).json({ error: 'Failed to post opname' });
  }
});

export default router;
